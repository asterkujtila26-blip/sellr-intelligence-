# SELLR.AI

Your personal AI business team. A Next.js 16 (App Router, TypeScript) product with Tailwind CSS + shadcn/ui, Prisma for all business data, and pluggable authentication: Supabase when configured, with a built-in local email/password fallback otherwise.

## Stack

- **Framework**: Next.js 16 App Router, TypeScript (strict)
- **UI**: Tailwind CSS 4, shadcn/ui (New York), Lucide icons, Framer Motion
- **Data**: Prisma (server-side ownership checks on every business query)
- **Auth**: Supabase (optional) or local bcrypt + signed-cookie sessions (fallback)
- **Whop**: STORE integration (`src/lib/whop`, `src/app/api/integrations/whop`) is a separate feature from Whop-as-a-login-method

## Getting started

```bash
bun install
cp .env.example .env.local   # fill in real values
bun run dev                  # http://localhost:3000
```

Useful scripts: `bun run lint` (ESLint), `bunx tsc --noEmit` (type check), `bun run db:generate` / `bun run db:migrate` (Prisma).

## Installation

Requirements: **Node.js 20+** (Node 22 recommended), **Bun 1.1+** (or npm/pnpm — `bun.lock` ships with the repository; other package managers will resolve from `package.json`).

```bash
git clone <your-repo-url> sellr-ai && cd sellr-ai
bun install                # installs dependencies and runs prisma generate via postinstall-safe flow
cp .env.example .env.local # then fill in the values (see Environment variables below)
bunx prisma generate       # generates the Prisma client into src/generated/prisma (already committed, idempotent)
bun run dev                # development server on http://localhost:3000
```

Production build (standalone output):

```bash
bun run build              # prisma generate && next build && assemble .next/standalone
bun run start              # serves the standalone build on port 3000
```

## Environment variables

Copy `.env.example` to `.env.local` (never commit real env files). The app reads:

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` or `POSTGRES_URL` | yes (production) | Prisma Postgres connection string (`postgres://...@pooled.db.prisma.io:5432/postgres?sslmode=require`). `POSTGRES_URL` wins if both are set — useful on hosts that pre-set `DATABASE_URL`. |
| `SESSION_SECRET` | recommended | Signing secret for the local-provider session cookie, min 32 chars. A fallback is generated and persisted to `db/.session-secret` on first boot. |
| `NEXT_PUBLIC_SUPABASE_URL` | for Supabase auth | Supabase project URL (no trailing slash). |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | for Supabase auth | Supabase publishable/anon key. |
| `NEXT_PUBLIC_OAUTH_PROVIDERS` | optional | Comma-separated OAuth buttons on the auth screen (`google,whop`). Empty = hidden. |
| `NEXT_PUBLIC_SITE_URL` | production | Absolute public origin used for email-action and OAuth redirects. |
| `WHOP_ENCRYPTION_KEY` | for Whop STORE integration | 64 hex chars (AES-256-GCM) encrypting Whop credentials at rest. |

Apply the database schema to a fresh Prisma Postgres database with `bunx prisma migrate deploy` (migration history ships in `prisma/migrations/`).

## Deployment (Vercel)

The repository is Vercel-ready out of the box:

1. **Import** the repository into Vercel (New Project → Import Git Repository). Vercel auto-detects Next.js; `bun.lock` makes Vercel use Bun for installs.
2. **Build command** — default `bun run build` works as-is: it runs `prisma generate` before `next build`, then assembles the standalone output. No override needed.
3. **Environment variables** — Project → Settings → Environment Variables, add (Production + Preview):
   - `POSTGRES_URL` (Prisma Postgres pooled connection string)
   - `SESSION_SECRET`
   - `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_OAUTH_PROVIDERS=google,whop`
   - `NEXT_PUBLIC_SITE_URL=https://<your-vercel-domain>` (or custom domain)
   - `WHOP_ENCRYPTION_KEY` if the Whop STORE integration is used
4. **Database** — deploy migrations once from your machine: `DATABASE_URL=<postgres-url> bunx prisma migrate deploy`.
5. **Supabase dashboard** — after the first deploy, add `https://<your-domain>/auth/callback` to Authentication → URL Configuration → Redirect URLs (production), and keep `http://localhost:3000/auth/callback` for local development. The Google/Whop provider setup steps are in the Authentication section above.

Deployments on any Node host also work via the standalone bundle: `bun run build`, then `NODE_ENV=production node .next/standalone/server.js` with the same environment variables.

### Security notes

- Never commit `.env`, `.env.local` or any file containing real credentials. This repository ships only `.env.example` (no secrets).
- The Supabase secret / service_role key is never used by the application code and must never be set as a `NEXT_PUBLIC_*` variable.
- Whop credentials are encrypted at rest (AES-256-GCM) with `WHOP_ENCRYPTION_KEY`; the key must be provided by the environment at runtime.

## Authentication

Auth is provider-switchable at runtime (`src/lib/supabase/config.ts`):

- **Supabase** — active when `NEXT_PUBLIC_SUPABASE_URL` **and** `NEXT_PUBLIC_SUPABASE_ANON_KEY` are set. Email confirmation, password recovery and OAuth flows all return through `src/app/auth/callback/route.ts`, the single return point.
- **Local fallback** — when those variables are absent, the app uses its built-in email/password provider (bcrypt hashes, httpOnly signed `sellr_session` cookie). This fallback must keep working; nothing else changes.

All business data always stays in Prisma with server-side ownership checks. Supabase is used for identity only; every Supabase user is mirrored into the Prisma `User` table with the same id (`ensureSupabaseProfile` in `src/lib/auth.ts`). The Supabase secret / service_role key is never used by the app and never exposed to client code.

### Environment variables

| Variable | Purpose |
| --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase project URL. Set together with the anon key to activate Supabase auth. |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase publishable key (`sb_publishable_...`) or legacy anon key — both work. Public by design; never put the secret key here. |
| `NEXT_PUBLIC_OAUTH_PROVIDERS` | Comma-separated OAuth buttons shown under the sign-in form, e.g. `google,whop`. Empty/unset hides the OAuth section. Supported: `google`, `whop`. |
| `NEXT_PUBLIC_SITE_URL` | Absolute public origin used for email-action and OAuth redirects (falls back to the request origin). Set it in production. |

### Provider setup (dashboards — configured outside this codebase)

**Google** (Supabase built-in provider `google`):

1. In [Google Cloud Console](https://console.cloud.google.com) create OAuth 2.0 credentials (Web application).
2. Authorized redirect URI: `<SUPABASE_URL>/auth/v1/callback` — exactly this URL, where `<SUPABASE_URL>` is your `NEXT_PUBLIC_SUPABASE_URL`.
3. Put the Google client id/secret in **Supabase > Authentication > Sign In / Up > Google** and enable the provider.

**Whop** (Supabase Custom OAuth provider `custom:whop`, manual OAuth2 configuration):

1. In **Supabase > Authentication > Sign In / Up**, add a **Custom OAuth provider** with id `whop` and set:
   - Authorization URL: `https://api.whop.com/oauth/authorize`
   - Token URL: `https://api.whop.com/oauth/token`
   - Userinfo URL: `https://api.whop.com/oauth/userinfo`
   - Scopes: `openid profile email`
2. In the Whop app's OAuth settings, set the redirect URI to the same `<SUPABASE_URL>/auth/v1/callback`.
3. Store the Whop client id/secret in the Supabase custom provider configuration.

**Supabase > Authentication > URL Configuration**:

- **Site URL**: your production origin (e.g. `https://your-app.example.com`).
- **Redirect URLs**: allow `<origin>/auth/callback` for every environment that signs in — production **and** `http://localhost:3000/auth/callback` for local development.

### Local development checklist

1. Set `NEXT_PUBLIC_SUPABASE_URL` + `NEXT_PUBLIC_SUPABASE_ANON_KEY` in `.env.local` and restart the dev server.
2. Set `NEXT_PUBLIC_OAUTH_PROVIDERS=google,whop` to render the buttons (they appear on both the **Sign in** and **Create account** screens).
3. Add `http://localhost:3000/auth/callback` to Supabase Redirect URLs.
4. Without these variables the app runs in local-provider mode: email/password, forgot/reset password and onboarding all keep working with zero configuration.

### Flow notes

- OAuth uses Supabase's PKCE flow: the browser goes provider-side, then returns to `/auth/callback?code=...`, where `exchangeCodeForSession` writes the session cookies before redirecting into the app.
- Sign-in errors reach the UI through `?auth_error=...` (picked up by `src/components/sellr/sellr-app.tsx`).
- Profile mapping: display name falls back `full_name -> name -> preferred_username -> email prefix`; avatar falls back `avatar_url -> picture` (Google sends `picture`).
