/**
 * Whop REST client (server-side only).
 *
 * Verified against the official Current API (v1):
 *   - Base: https://api.whop.com/api/v1 (production) | https://sandbox-api.whop.com/api/v1
 *   - Auth: `Authorization: Bearer <Account API key>` (server only, never client)
 *   - Version pin: `Api-Version-Date` header on every request
 *   - Pagination: cursor-based (`after` cursor + `first` page size + optional
 *     `include_total_count`), verified in openapi.json
 *
 * Endpoints used (all GET, read-only — this integration never mutates Whop):
 *   GET /accounts/me            → credential verification + account identity
 *   GET /payments               → paid sales (total, amount_after_fees, currency, paid_at)
 *   GET /memberships            → membership states (active/canceled/…)
 *   GET /products               → product catalog (names for display)
 *   POST /webhooks, DELETE /webhooks/{id} → webhook registration lifecycle
 *
 * Only response fields that are explicitly verified in the OpenAPI schema are
 * typed and used. Everything else is ignored.
 */

import { whopApiBase, WHOP_API_VERSION_DATE, type WhopEnvironment } from './config'

export class WhopApiError extends Error {
  status: number
  /** Machine-readable kind for the UI: invalid_key | insufficient_permission | rate_limited | downtime | error */
  kind: 'invalid_key' | 'insufficient_permission' | 'rate_limited' | 'downtime' | 'error'
  retryAfterSec: number | null

  constructor(status: number, kind: WhopApiError['kind'], message: string, retryAfterSec: number | null = null) {
    super(message)
    this.name = 'WhopApiError'
    this.status = status
    this.kind = kind
    this.retryAfterSec = retryAfterSec
  }
}

const REQUEST_TIMEOUT_MS = 20_000
const MAX_PAGES_PER_RESOURCE = 40
const PAGE_SIZE = 100

interface WhopPage<T> {
  data: T[]
  /** Cursor for the next page (id of the last item), null when exhausted. */
  after: string | null
  totalCount: number | null
}

export interface WhopAccount {
  id: string
  title: string | null
  businessName: string | null
  route: string | null
  status: string | null
}

export interface WhopPayment {
  id: string
  status: string
  billingReason: string | null
  total: number
  subtotal: number | null
  taxAmount: number | null
  refundedAmount: number | null
  amountAfterFees: number | null
  usdTotal: number | null
  currency: string
  createdAt: string
  paidAt: string | null
  productId: string | null
  variantId: string | null
  membershipId: string | null
  user: { id: string | null; email: string | null } | null
}

export interface WhopMembership {
  id: string
  status: string
  createdAt: string
  expiresAt: string | null
  currentPeriodEnd: string | null
  renewalPrice: number | null
  initialPrice: number | null
  productId: string | null
  userId: string | null
}

export interface WhopProduct {
  id: string
  title: string | null
}

export interface WhopWebhookRegistration {
  id: string
  secret: string
}

// ---- transport ----

interface RequestOptions {
  method?: 'GET' | 'POST' | 'DELETE'
  body?: unknown
  /** Server-side correlation info for logs — NEVER the credential itself. */
  context?: string
}

async function whopRequest<T>(
  environment: WhopEnvironment,
  apiKey: string,
  path: string,
  options: RequestOptions = {}
): Promise<T> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)
  let res: Response
  try {
    res = await fetch(`${whopApiBase(environment)}${path}`, {
      method: options.method ?? 'GET',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: 'application/json',
        'Api-Version-Date': WHOP_API_VERSION_DATE,
        ...(options.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      },
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
      signal: controller.signal,
      cache: 'no-store',
    })
  } catch (e) {
    // Network failure / timeout — Whop unreachable.
    throw new WhopApiError(
      503,
      'downtime',
      'Whop is not reachable right now. Please try again in a moment.',
      null
    )
  } finally {
    clearTimeout(timeout)
  }

  if (!res.ok) {
    const retryAfter = res.headers.get('retry-after')
    const retrySec = retryAfter && /^\d+$/.test(retryAfter) ? Number(retryAfter) : null
    let bodyText = ''
    try {
      bodyText = (await res.json()) as string
      bodyText = typeof bodyText === 'string' ? bodyText : JSON.stringify(bodyText)
    } catch {
      bodyText = ''
    }
    // Log server-side without ever echoing the credential.
    console.error('[SELLR Whop] API error', {
      status: res.status,
      path,
      context: options.context ?? '',
      // Truncated body only — keys never appear in Whop error bodies, and we
      // never log request headers.
      body: bodyText.slice(0, 400),
    })
    if (res.status === 401) {
      throw new WhopApiError(401, 'invalid_key', 'Whop rejected this API key. Check that the key is valid, active, and from the same environment (sandbox vs. production).')
    }
    if (res.status === 403) {
      throw new WhopApiError(403, 'insufficient_permission', 'This Whop API key does not have permission to read the requested data. Create a key with payments/membership read permissions.')
    }
    if (res.status === 429) {
      throw new WhopApiError(429, 'rate_limited', `Whop rate limit reached. Try again${retrySec ? ` in ${retrySec}s` : ' shortly'}.`, retrySec)
    }
    if (res.status >= 500) {
      throw new WhopApiError(502, 'downtime', 'Whop is having a temporary problem. Please try again in a moment.', null)
    }
    throw new WhopApiError(res.status, 'error', `Whop request failed (${res.status}).`)
  }

  return (await res.json()) as T
}

// ---- pagination ----

/**
 * Walk a cursor-paginated list. Whop returns `{ data, meta }` where the next
 * cursor is the id of the last returned row; when a page returns fewer rows
 * than requested (or an empty array), the list is exhausted.
 */
async function listAll<T>(
  environment: WhopEnvironment,
  apiKey: string,
  basePath: string,
  params: Record<string, string>,
  context: string,
  onPage?: (page: WhopPage<T>) => void
): Promise<{ items: T[]; totalCount: number | null; pages: number }> {
  const items: T[] = []
  let after: string | null = null
  let totalCount: number | null = null
  let pages = 0

  for (;;) {
    if (pages >= MAX_PAGES_PER_RESOURCE) {
      throw new WhopApiError(
        400,
        'error',
        `Too much Whop data to synchronize in one pass (${MAX_PAGES_PER_RESOURCE}+ pages for ${context}). Please contact support.`
      )
    }
    const search = new URLSearchParams({ first: String(PAGE_SIZE), ...params })
    if (after) search.set('after', after)
    const res = await whopRequest<{ data?: T[]; meta?: { total_count?: number; next?: string | null } }>(
      environment,
      apiKey,
      `${basePath}?${search.toString()}`,
      { context }
    )
    const rows = Array.isArray(res.data) ? res.data : []
    items.push(...rows)
    totalCount = res.meta?.total_count ?? totalCount
    pages += 1
    onPage?.({ data: rows, after, totalCount })
    if (rows.length < PAGE_SIZE) break
    const lastId = (rows[rows.length - 1] as { id?: unknown } | undefined)?.id
    if (typeof lastId !== 'string' || !lastId) break
    after = lastId
  }
  return { items, totalCount, pages }
}

// ---- typed resource calls ----

/** GET /accounts/me — verifies the key and returns the account it belongs to. */
export async function fetchAccount(environment: WhopEnvironment, apiKey: string): Promise<WhopAccount> {
  const raw = await whopRequest<Record<string, unknown>>(environment, apiKey, '/accounts/me', {
    context: 'accounts/me',
  })
  return {
    id: typeof raw.id === 'string' ? raw.id : '',
    title: typeof raw.title === 'string' ? raw.title : null,
    businessName: typeof raw.business_name === 'string' ? raw.business_name : null,
    route: typeof raw.route === 'string' ? raw.route : null,
    status: typeof raw.status === 'string' ? raw.status : null,
  }
}

interface RawPayment {
  id?: string
  status?: string
  billing_reason?: string
  total?: number
  subtotal?: number
  tax_amount?: number
  refunded_amount?: number
  amount_after_fees?: number
  usd_total?: number
  currency?: string
  created_at?: string
  paid_at?: string
  product_id?: string
  variant_id?: string
  membership_id?: string
  user?: { id?: string; email?: string }
}

function mapPayment(raw: RawPayment): WhopPayment | null {
  if (!raw.id || typeof raw.status !== 'string' || typeof raw.currency !== 'string') return null
  return {
    id: raw.id,
    status: raw.status,
    billingReason: typeof raw.billing_reason === 'string' ? raw.billing_reason : null,
    total: typeof raw.total === 'number' ? raw.total : 0,
    subtotal: typeof raw.subtotal === 'number' ? raw.subtotal : null,
    taxAmount: typeof raw.tax_amount === 'number' ? raw.tax_amount : null,
    refundedAmount: typeof raw.refunded_amount === 'number' ? raw.refunded_amount : null,
    amountAfterFees: typeof raw.amount_after_fees === 'number' ? raw.amount_after_fees : null,
    usdTotal: typeof raw.usd_total === 'number' ? raw.usd_total : null,
    currency: raw.currency,
    createdAt: typeof raw.created_at === 'string' ? raw.created_at : new Date().toISOString(),
    paidAt: typeof raw.paid_at === 'string' ? raw.paid_at : null,
    productId: typeof raw.product_id === 'string' ? raw.product_id : null,
    variantId: typeof raw.variant_id === 'string' ? raw.variant_id : null,
    membershipId: typeof raw.membership_id === 'string' ? raw.membership_id : null,
    user:
      raw.user && typeof raw.user === 'object'
        ? {
            id: typeof raw.user.id === 'string' ? raw.user.id : null,
            email: typeof raw.user.email === 'string' ? raw.user.email : null,
          }
        : null,
  }
}

/** GET /payments — all payments for the account (read-only; no status filter so the sync can reason about refunds itself). */
export async function fetchAllPayments(
  environment: WhopEnvironment,
  apiKey: string,
  accountId: string
): Promise<WhopPayment[]> {
  const { items } = await listAll<RawPayment>(
    environment,
    apiKey,
    '/payments',
    { account_id: accountId, order: 'created_at', direction: 'asc', include_total_count: 'true' },
    'payments'
  )
  return items.map(mapPayment).filter((p): p is WhopPayment => p !== null)
}

interface RawMembership {
  id?: string
  status?: string
  created_at?: string
  expires_at?: string
  current_period_end?: string
  renewal_price?: number
  initial_price?: number
  product_id?: string
  user_id?: string
}

export async function fetchAllMemberships(
  environment: WhopEnvironment,
  apiKey: string,
  accountId: string
): Promise<WhopMembership[]> {
  const { items } = await listAll<RawMembership>(
    environment,
    apiKey,
    '/memberships',
    { account_id: accountId, order: 'created_at', direction: 'asc', include_total_count: 'true' },
    'memberships'
  )
  return items
    .filter((m): m is RawMembership & { id: string; status: string } => Boolean(m.id && typeof m.status === 'string'))
    .map((m) => ({
      id: m.id,
      status: m.status,
      createdAt: typeof m.created_at === 'string' ? m.created_at : new Date().toISOString(),
      expiresAt: typeof m.expires_at === 'string' ? m.expires_at : null,
      currentPeriodEnd: typeof m.current_period_end === 'string' ? m.current_period_end : null,
      renewalPrice: typeof m.renewal_price === 'number' ? m.renewal_price : null,
      initialPrice: typeof m.initial_price === 'number' ? m.initial_price : null,
      productId: typeof m.product_id === 'string' ? m.product_id : null,
      userId: typeof m.user_id === 'string' ? m.user_id : null,
    }))
}

interface RawProduct {
  id?: string
  title?: string
}

export async function fetchAllProducts(
  environment: WhopEnvironment,
  apiKey: string,
  accountId: string
): Promise<WhopProduct[]> {
  const { items } = await listAll<RawProduct>(
    environment,
    apiKey,
    '/products',
    { account_id: accountId, include_total_count: 'true' },
    'products'
  )
  return items
    .filter((p): p is RawProduct & { id: string } => Boolean(p.id))
    .map((p) => ({ id: p.id, title: typeof p.title === 'string' ? p.title : null }))
}

// ---- webhook registration lifecycle ----

/** POST /webhooks — register the SELLR webhook endpoint for this account. */
export async function registerWebhook(
  environment: WhopEnvironment,
  apiKey: string,
  url: string,
  events: readonly string[]
): Promise<WhopWebhookRegistration> {
  const raw = await whopRequest<{ id?: string; webhook_secret?: string }>(environment, apiKey, '/webhooks', {
    method: 'POST',
    body: { url, events, enabled: true, title: 'SELLR.AI business sync' },
    context: 'webhooks/register',
  })
  if (!raw.id || !raw.webhook_secret) {
    throw new WhopApiError(502, 'error', 'Whop did not return a webhook secret. Webhook registration failed.')
  }
  return { id: raw.id, secret: raw.webhook_secret }
}

/** DELETE /webhooks/{id} — remove the webhook on disconnect. Best-effort. */
export async function deleteWebhook(
  environment: WhopEnvironment,
  apiKey: string,
  webhookId: string
): Promise<void> {
  await whopRequest<unknown>(environment, apiKey, `/webhooks/${webhookId}`, {
    method: 'DELETE',
    context: 'webhooks/delete',
  })
}
