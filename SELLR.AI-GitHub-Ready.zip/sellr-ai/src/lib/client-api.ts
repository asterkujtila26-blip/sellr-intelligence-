/** Client-side fetch wrapper with consistent error extraction. */
export async function apiFetch<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    cache: 'no-store',
    ...options,
  })
  let data: unknown = null
  try {
    data = await res.json()
  } catch {
    // Non-JSON response (e.g. network gateway error)
  }
  if (!res.ok) {
    const message =
      (data && typeof data === 'object' && 'error' in data && typeof (data as { error: unknown }).error === 'string'
        ? (data as { error: string }).error
        : null) ?? `Request failed (${res.status})`
    throw new Error(message)
  }
  return data as T
}
