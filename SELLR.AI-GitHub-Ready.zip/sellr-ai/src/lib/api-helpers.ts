import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { ZodError } from 'zod'

export class ApiError extends Error {
  status: number
  constructor(status: number, message: string) {
    super(message)
    this.status = status
  }
}

export function errorResponse(e: unknown): NextResponse {
  if (e instanceof ApiError) {
    return NextResponse.json({ error: e.message }, { status: e.status })
  }
  if (e instanceof ZodError) {
    const message = e.issues[0]?.message ?? 'Invalid input'
    return NextResponse.json({ error: message }, { status: 400 })
  }
  // Network-level failures (e.g. the auth provider is unreachable) should
  // read as a temporary service problem, not a raw stack trace.
  if (e instanceof TypeError && /fetch failed|network/i.test(e.message)) {
    console.error('[SELLR API] Upstream unreachable:', e)
    return NextResponse.json(
      { error: 'Authentication service is temporarily unreachable. Please try again.' },
      { status: 503 }
    )
  }
  console.error('[SELLR API]', e)
  return NextResponse.json(
    { error: 'Something went wrong on our side. Please try again.' },
    { status: 500 }
  )
}

const MUTATING_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE'])

/** Extract the hostname (no scheme, no port) from a URL or bare authority. */
function hostnameOf(value: string): string | null {
  const v = value.trim()
  if (!v) return null
  // Full URL — let the URL parser do the work.
  if (/^https?:\/\//i.test(v)) {
    try {
      return new URL(v).hostname.toLowerCase() || null
    } catch {
      return null
    }
  }
  // Bare authority (host[:port] / [ipv6]:port). NOTE: new URL('host:port')
  // would mis-parse this as an opaque non-special URL (protocol 'host:',
  // empty hostname), so strip the port manually.
  const authority = v.toLowerCase().split(/[/?#]/)[0]
  const host = authority.replace(/:\d+$/, '').replace(/^\[|\]$/g, '')
  return host || null
}

/**
 * Resolve the PUBLIC origin the browser actually sees, for building absolute
 * URLs that the browser must open (email action links, reset links).
 *
 * Priority:
 *   1. NEXT_PUBLIC_SITE_URL / SITE_URL — explicit deployment configuration.
 *   2. The request's Origin header — the browser-visible truth in environments
 *      where an outer edge rewrites Host/x-forwarded-host to an internal
 *      gateway host. SECURITY: mutating handlers MUST run assertSameOrigin(req)
 *      before calling this — any Origin that survives that check is already
 *      validated against the trusted-origin policy, so it can never be an
 *      attacker-chosen host. GET callers (email callbacks) only reach the
 *      Origin branch when a browser explicitly sent one.
 *   3. x-forwarded-host + x-forwarded-proto — legacy fallback.
 */
export function resolvePublicOrigin(req: NextRequest): string {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? process.env.SITE_URL
  if (siteUrl) return siteUrl.replace(/\/$/, '')

  const origin = req.headers.get('origin')
  if (origin && /^https?:\/\//i.test(origin)) {
    try {
      return new URL(origin).origin
    } catch {
      // Malformed Origin — fall through to forwarded headers.
    }
  }

  const proto = req.headers.get('x-forwarded-proto')?.split(',')[0]?.trim() || 'http'
  const host =
    req.headers.get('x-forwarded-host')?.split(',')[0]?.trim() ||
    req.headers.get('host') ||
    'localhost:3000'
  return `${proto}://${host}`
}

/**
 * CSRF defense for state-changing API requests: when a browser sends a
 * POST/PUT/PATCH/DELETE it always attaches an Origin header. If that Origin's
 * host is not the app's own host, reject the request.
 *
 * The comparison is HOSTNAME-based (scheme- and port-agnostic): TLS terminates
 * at the edge, so the browser's Origin is https while the app internally sees
 * http, and preview edges may append/strip ports on forwarded hosts. A foreign
 * origin still has a foreign hostname, so the defense holds.
 *
 * Requests without an Origin header (curl, server-to-server, same-origin
 * navigations) are allowed — they cannot be cross-site browser forgeries.
 * `TRUSTED_ORIGIN_HOSTS` (comma-separated) provides an escape hatch for
 * environments where the edge rewrites the Host header entirely.
 *
 * `TRUSTED_ORIGIN_SUFFIXES` (comma-separated) extends that escape hatch to
 * platform-managed, session-scoped preview hosts: when the outer edge
 * rewrites Host to its own backend hostname (e.g. preview panels served at
 * preview-chat-<session>.space-z.ai with Host rewritten to an internal
 * gateway host), no exact-host match can ever succeed. An Origin whose
 * hostname equals a listed suffix OR is a dot-boundary subdomain of it is
 * accepted. The dot boundary is enforced, so suffix "space-z.ai" matches
 * "preview-chat-123.space-z.ai" but never "evil-space-z.ai". A browser
 * cannot forge Origin, so this only admits origins on the platform's own
 * edge domain.
 *
 * Must be called at the top of every mutating route handler.
 */
export function assertSameOrigin(req: NextRequest): void {
  if (!MUTATING_METHODS.has(req.method.toUpperCase())) return

  const origin = req.headers.get('origin')
  if (!origin) return

  const originHost = hostnameOf(origin)
  if (!originHost) {
    // Opaque origin ("null") — always reject for state changes.
    console.error('[SELLR API] Rejected mutating request with opaque Origin', {
      method: req.method,
      path: req.nextUrl.pathname,
      origin,
    })
    throw new ApiError(403, 'Request blocked: cross-origin requests are not allowed.')
  }

  const candidates = new Set<string>()
  const addCandidate = (value?: string | null) => {
    if (!value) return
    const first = value.split(',')[0]?.trim().toLowerCase()
    if (!first) return
    candidates.add(first)
    const host = hostnameOf(first)
    if (host) candidates.add(host)
  }

  addCandidate(req.headers.get('x-forwarded-host'))
  addCandidate(req.headers.get('host'))
  addCandidate(process.env.NEXT_PUBLIC_SITE_URL)
  addCandidate(process.env.SITE_URL)
  for (const extra of (process.env.TRUSTED_ORIGIN_HOSTS ?? '').split(',')) {
    addCandidate(extra)
  }

  // Platform-managed edge domains (dot-boundary suffix match).
  const trustedSuffixes = (process.env.TRUSTED_ORIGIN_SUFFIXES ?? '')
    .split(',')
    .map((s) => s.trim().toLowerCase().replace(/^\*+\./, ''))
    .filter(Boolean)
  const matchesTrustedSuffix = trustedSuffixes.some(
    (suffix) => originHost === suffix || originHost.endsWith(`.${suffix}`)
  )

  if (!candidates.has(originHost) && !matchesTrustedSuffix) {
    // Diagnostic line: makes a misconfigured edge immediately visible in logs.
    console.error('[SELLR API] Cross-origin request rejected', {
      method: req.method,
      path: req.nextUrl.pathname,
      origin,
      originHost,
      host: req.headers.get('host'),
      xForwardedHost: req.headers.get('x-forwarded-host'),
      xForwardedProto: req.headers.get('x-forwarded-proto'),
    })
    throw new ApiError(403, 'Request blocked: cross-origin requests are not allowed.')
  }
}
