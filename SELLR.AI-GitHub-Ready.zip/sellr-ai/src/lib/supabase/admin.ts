import { createClient } from '@supabase/supabase-js'
import { SUPABASE_SERVICE_ROLE_KEY, SUPABASE_URL, isSupabaseConfigured } from './config'

/**
 * ADMIN client — service_role key. BYPASSES Row Level Security.
 *
 * Hard rules enforced here:
 *  1. Server-only. Throws immediately if imported into a browser bundle.
 *  2. Requires SUPABASE_SERVICE_ROLE_KEY to be set. Without it the app
 *     falls back to the anon-level server client everywhere.
 *
 * Use ONLY for trusted server-side operations (admin jobs, cleanups).
 * Normal request handling must use createSupabaseServerClient() so RLS and
 * user-scoping stay enforced.
 */
export function createSupabaseAdminClient() {
  if (typeof window !== 'undefined') {
    throw new Error(
      'createSupabaseAdminClient must never be used in the browser. service_role is server-only.'
    )
  }
  if (!isSupabaseConfigured || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('Supabase admin client requires SUPABASE_URL, ANON_KEY and SUPABASE_SERVICE_ROLE_KEY.')
  }

  return createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  })
}
