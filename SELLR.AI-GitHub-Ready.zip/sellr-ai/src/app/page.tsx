import { SellrApp } from '@/components/sellr/sellr-app'

export default function Home() {
  return <SellrApp />
}
