import { NextRequest, NextResponse } from 'next/server'
import { isSupabaseConfigured } from '@/lib/supabase/config'
import { createSupabaseServerClient } from '@/lib/supabase/server'
import { resolvePublicOrigin } from '@/lib/api-helpers'

/**
 * Email action handler (confirmation & recovery links).
 *
 * Flow: Supabase email link → /auth/callback?code=<pkce-code> →
 * exchangeCodeForSession (server, cookies written) → redirect into the app.
 *
 * `next` is restricted to in-app paths to prevent open redirects.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  // Public browser-visible origin (NOT the edge-rewritten internal host).
  const origin = resolvePublicOrigin(req)
  const code = searchParams.get('code')
  const error = searchParams.get('error')
  const errorDescription = searchParams.get('error_description')

  // Only allow same-app relative destinations.
  const rawNext = searchParams.get('next') ?? '/'
  const next = rawNext.startsWith('/') && !rawNext.startsWith('//') ? rawNext : '/'

  if (error) {
    const message = errorDescription || error
    return NextResponse.redirect(
      `${origin}/?auth_error=${encodeURIComponent(message)}`
    )
  }

  if (!code) {
    return NextResponse.redirect(`${origin}/?auth_error=${encodeURIComponent('Missing confirmation code.')}`)
  }

  if (!isSupabaseConfigured) {
    return NextResponse.redirect(`${origin}/`)
  }

  try {
    const supabase = await createSupabaseServerClient()
    const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code)
    if (exchangeError) {
      return NextResponse.redirect(
        `${origin}/?auth_error=${encodeURIComponent(exchangeError.message)}`
      )
    }
    return NextResponse.redirect(`${origin}${next}`)
  } catch {
    return NextResponse.redirect(
      `${origin}/?auth_error=${encodeURIComponent('Could not complete sign-in. Please try again.')}`
    )
  }
}
