import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SELLR.AI — Your Personal AI Business Team",
  description:
    "A coordinated team of AI agents — CEO, Analyst, Growth, Retention and Operations — that helps you understand, manage and grow your online business. See, decide, execute, measure.",
  keywords: ["AI business team", "AI agents", "SaaS", "SELLR.AI", "business intelligence"],
  authors: [{ name: "SELLR.AI" }],
};

export const viewport: Viewport = {
  themeColor: "#0b0b0c",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        {children}
        <Toaster position="top-right" />
      </body>
    </html>
  );
}
