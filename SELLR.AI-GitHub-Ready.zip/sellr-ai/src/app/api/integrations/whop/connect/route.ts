import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse, resolvePublicOrigin } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'
import { whopConnectSchema } from '@/lib/validation'
import { rateLimit } from '@/lib/rate-limit'
import { logActivity } from '@/lib/activity'
import { fetchAccount, registerWebhook, deleteWebhook, WhopApiError } from '@/lib/whop/client'
import { sealSecret, openSecret, WhopCryptoConfigError } from '@/lib/whop/crypto'
import {
  isWhopEncryptionConfigured,
  isWhopWebhookConfigured,
  PUBLIC_APP_URL,
  WHOP_WEBHOOK_EVENTS,
  isWhopEnvironment,
  type WhopEnvironment,
} from '@/lib/whop/config'
import { synchronizeBusiness } from '@/lib/whop/sync'
import { buildWhopStatus } from '@/lib/whop/status'

/**
 * Public origin for webhook registration (same convention as the auth email
 * links): PUBLIC_APP_URL env when set, else resolvePublicOrigin(req) — which
 * prefers the browser-visible request Origin. Do NOT trust x-forwarded-host
 * here: the outer edge rewrites it to an internal gateway host, and a webhook
 * registered against that host could never be reached by Whop's servers.
 */
function getPublicOrigin(req: NextRequest): string {
  if (PUBLIC_APP_URL) return PUBLIC_APP_URL
  return resolvePublicOrigin(req)
}

/**
 * Connect a Whop business to a SELLR business.
 *
 * Flow: auth → ownership → config checks → verify the key against the real
 * Whop API (GET /accounts/me) → encrypt + store → register the webhook
 * (best-effort) → run the first synchronization → return the public status.
 * The user is never shown "Connected" unless server-side verification
 * succeeded — everything before that surfaces an error.
 */
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()

    const rl = rateLimit(`whop-connect:${user.id}`, 6, 10 * 60_000)
    if (!rl.ok) {
      throw new ApiError(429, `Too many connection attempts. Try again in ${rl.retryAfterSec}s.`)
    }

    const business = await requireBusiness(user.id)

    if (!isWhopEncryptionConfigured()) {
      throw new ApiError(
        503,
        'Whop credential storage is not configured on this server. Set WHOP_ENCRYPTION_KEY (64 hex characters) and restart the app.'
      )
    }

    const input = whopConnectSchema.parse(await req.json())
    if (!isWhopEnvironment(input.environment)) {
      throw new ApiError(400, 'Unknown Whop environment.')
    }
    const environment: WhopEnvironment = input.environment

    // --- Verify the credential against the REAL Whop API (no fakes) ---
    let account
    try {
      account = await fetchAccount(environment, input.apiKey)
    } catch (e) {
      if (e instanceof WhopApiError) {
        throw new ApiError(e.status === 503 || e.status === 502 ? 502 : 400, e.message)
      }
      throw e
    }
    if (!account.id || !account.id.startsWith('biz_')) {
      throw new ApiError(400, 'Whop did not return a valid business account for this key.')
    }

    // --- Encrypt the credential (config already validated above) ---
    const sealed = sealSecret(input.apiKey)

    const existing = await db.whopConnection.findUnique({ where: { businessId: business.id } })

    // Best-effort cleanup of a previous webhook when replacing the key.
    if (existing?.webhookId && existing.webhookEncryptedSecret) {
      try {
        const oldKey = openSecret({
          ciphertext: existing.encryptedKey,
          iv: existing.keyIv,
          tag: existing.keyTag,
        })
        await deleteWebhook(existing.environment as WhopEnvironment, oldKey, existing.webhookId)
      } catch {
        // Old webhook may already be gone or the old key revoked — ignore.
      }
    }

    const data = {
      businessId: business.id,
      ownerId: user.id,
      encryptedKey: sealed.ciphertext,
      keyIv: sealed.iv,
      keyTag: sealed.tag,
      keyHint: input.apiKey.slice(-4),
      whopAccountId: account.id,
      whopAccountName: account.businessName ?? account.title,
      whopRoute: account.route,
      environment,
      status: 'CONNECTED',
      lastSyncAt: null,
      lastSyncError: null,
      lastSyncSummary: null,
      lastVerifiedAt: new Date(),
    }

    const connection = await db.whopConnection.upsert({
      where: { businessId: business.id },
      create: { ...data },
      update: {
        ...data,
        webhookId: null,
        webhookEncryptedSecret: null,
        webhookSecretIv: null,
        webhookSecretTag: null,
      },
    })

    // --- Register the webhook (best-effort — connection still stands) ---
    const origin = getPublicOrigin(req)
    if (origin) {
      try {
        const registration = await registerWebhook(
          environment,
          input.apiKey,
          `${origin}/api/integrations/whop/webhook`,
          WHOP_WEBHOOK_EVENTS
        )
        const sealedSecret = sealSecret(registration.secret)
        await db.whopConnection.update({
          where: { id: connection.id },
          data: {
            webhookId: registration.id,
            webhookEncryptedSecret: sealedSecret.ciphertext,
            webhookSecretIv: sealedSecret.iv,
            webhookSecretTag: sealedSecret.tag,
          },
        })
      } catch (e) {
        console.warn('[SELLR Whop] webhook registration failed (connection still valid)', {
          message: e instanceof Error ? e.message : String(e),
        })
      }
    }

    await logActivity(
      business.id,
      'WHOP_CONNECTED',
      `Whop account connected: ${account.businessName ?? account.title ?? account.id} (${environment})`,
      null
    )

    // --- First synchronization (awaited so the user sees real results) ---
    await synchronizeBusiness(connection.id)

    const status = await buildWhopStatus(business.id)
    return NextResponse.json(status)
  } catch (e) {
    if (e instanceof WhopCryptoConfigError) {
      return errorResponse(new ApiError(503, e.message))
    }
    return errorResponse(e)
  }
}
