import { NextRequest, NextResponse } from 'next/server'
import { createHash } from 'crypto'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { hashPassword } from '@/lib/auth'
import { resetPasswordSchema } from '@/lib/validation'
import { rateLimit } from '@/lib/rate-limit'
import { isSupabaseConfigured } from '@/lib/supabase/config'
import { createSupabaseServerClient } from '@/lib/supabase/server'
import { mapSupabaseAuthError } from '@/lib/supabase/errors'

function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex')
}

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local'
    const rl = rateLimit(`reset:${ip}`, 10, 10 * 60_000)
    if (!rl.ok) {
      throw new ApiError(429, `Too many attempts. Try again in ${rl.retryAfterSec}s.`)
    }

    const body = await req.json()
    const input = resetPasswordSchema.parse(body)

    // ---------------- Supabase provider ----------------
    // Requires the recovery session created by /auth/callback.
    if (isSupabaseConfigured && !input.token) {
      const supabase = await createSupabaseServerClient()
      const { data, error: userErr } = await supabase.auth.getUser()
      if (userErr || !data.user) {
        throw new ApiError(401, 'Your reset link is invalid or has expired. Request a new one.')
      }
      const { error } = await supabase.auth.updateUser({ password: input.password })
      if (error) throw mapSupabaseAuthError(error)
      return NextResponse.json({ ok: true })
    }

    // ---------------- Local provider (token flow) ----------------
    if (!input.token) {
      throw new ApiError(400, 'Missing reset token. Request a new reset link.')
    }

    const record = await db.passwordResetToken.findUnique({
      where: { tokenHash: hashToken(input.token) },
    })
    if (!record || record.usedAt || record.expiresAt < new Date()) {
      throw new ApiError(400, 'This reset link is invalid or has expired. Request a new one.')
    }

    const passwordHash = await hashPassword(input.password)
    await db.$transaction([
      db.user.update({ where: { id: record.userId }, data: { passwordHash } }),
      db.passwordResetToken.update({
        where: { id: record.id },
        data: { usedAt: new Date() },
      }),
      // Security: invalidate all other outstanding tokens for this user.
      db.passwordResetToken.deleteMany({
        where: { userId: record.userId, usedAt: null, id: { not: record.id } },
      }),
    ])

    return NextResponse.json({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
