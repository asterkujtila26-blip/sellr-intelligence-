import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { errorResponse } from '@/lib/api-helpers'
import { getAuthProvider } from '@/lib/supabase/config'

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ user: null, business: null, provider: getAuthProvider() })
    }
    const business = await db.business.findFirst({ where: { ownerId: user.id } })
    return NextResponse.json({ user, business, provider: getAuthProvider() })
  } catch (e) {
    return errorResponse(e)
  }
}
