import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse, resolvePublicOrigin } from '@/lib/api-helpers'
import { createSession, ensureSupabaseProfile, hashPassword } from '@/lib/auth'
import { registerSchema } from '@/lib/validation'
import { rateLimit } from '@/lib/rate-limit'
import { isSupabaseConfigured } from '@/lib/supabase/config'
import { createSupabaseServerClient } from '@/lib/supabase/server'
import { mapSupabaseAuthError } from '@/lib/supabase/errors'

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local'
    const rl = rateLimit(`register:${ip}`, 10, 5 * 60_000)
    if (!rl.ok) {
      throw new ApiError(429, `Too many attempts. Try again in ${rl.retryAfterSec}s.`)
    }

    const body = await req.json()
    const input = registerSchema.parse(body)

    // ---------------- Supabase provider ----------------
    if (isSupabaseConfigured) {
      const supabase = await createSupabaseServerClient()
      const { data, error } = await supabase.auth.signUp({
        email: input.email,
        password: input.password,
        options: {
          data: { full_name: input.fullName },
          emailRedirectTo: `${resolvePublicOrigin(req)}/auth/callback`,
        },
      })
      if (error) throw mapSupabaseAuthError(error)

      // Email confirmation enabled → no session yet; user must verify.
      if (!data.session) {
        return NextResponse.json({ requiresVerification: true, email: input.email })
      }
      if (!data.user) {
        throw new ApiError(500, 'Sign-up succeeded but no user was returned. Please try again.')
      }

      // Auto-confirm enabled → session established (cookies set by the
      // server client). Sync the local profile row immediately.
      const identity = await ensureSupabaseProfile(data.user)
      return NextResponse.json({ user: { id: identity.id, email: identity.email, fullName: identity.fullName, avatarUrl: identity.avatarUrl } })
    }

    // ---------------- Local provider (fallback) ----------------
    const existing = await db.user.findUnique({ where: { email: input.email } })
    if (existing) {
      throw new ApiError(409, 'An account with this email already exists. Try signing in.')
    }

    const passwordHash = await hashPassword(input.password)
    const user = await db.user.create({
      data: { email: input.email, fullName: input.fullName, passwordHash, emailVerifiedAt: new Date() },
      select: { id: true, email: true, fullName: true, avatarUrl: true },
    })

    await createSession(user.id)
    return NextResponse.json({ user })
  } catch (e) {
    return errorResponse(e)
  }
}
