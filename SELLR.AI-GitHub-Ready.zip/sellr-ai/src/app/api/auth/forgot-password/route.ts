import { NextRequest, NextResponse } from 'next/server'
import { randomBytes, createHash } from 'crypto'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse, resolvePublicOrigin } from '@/lib/api-helpers'
import { forgotPasswordSchema } from '@/lib/validation'
import { rateLimit } from '@/lib/rate-limit'
import { isSupabaseConfigured } from '@/lib/supabase/config'
import { createSupabaseServerClient } from '@/lib/supabase/server'
import { mapSupabaseAuthError } from '@/lib/supabase/errors'

function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex')
}

/**
 * Always responds { ok: true } — never reveals whether the email exists.
 */
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local'
    const rl = rateLimit(`forgot:${ip}`, 6, 10 * 60_000)
    if (!rl.ok) {
      throw new ApiError(429, `Too many requests. Try again in ${rl.retryAfterSec}s.`)
    }

    const body = await req.json()
    const { email } = forgotPasswordSchema.parse(body)

    // ---------------- Supabase provider ----------------
    // Supabase sends the recovery email itself (real email delivery).
    if (isSupabaseConfigured) {
      const supabase = await createSupabaseServerClient()
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${resolvePublicOrigin(req)}/auth/callback?next=/reset`,
      })
      if (error) throw mapSupabaseAuthError(error)
      return NextResponse.json({ ok: true })
    }

    // ---------------- Local provider (fallback) ----------------
    const user = await db.user.findUnique({ where: { email } })
    let resetUrl: string | undefined
    if (user && user.passwordHash) {
      // Invalidate any previous reset tokens for this user.
      await db.passwordResetToken.deleteMany({ where: { userId: user.id } })

      const rawToken = randomBytes(32).toString('base64url')
      await db.passwordResetToken.create({
        data: {
          userId: user.id,
          tokenHash: hashToken(rawToken),
          expiresAt: new Date(Date.now() + 60 * 60_000), // 1 hour
        },
      })

      // No SMTP/mail service is configured in this environment, so the reset
      // link is returned for dev environments instead of being emailed.
      // In production, wire a mail provider and deliver this URL by email.
      resetUrl = `${resolvePublicOrigin(req)}/?reset=${rawToken}`
    }

    return NextResponse.json({ ok: true, ...(resetUrl ? { resetUrl } : {}) })
  } catch (e) {
    return errorResponse(e)
  }
}
