import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { createSession, ensureSupabaseProfile, verifyPassword } from '@/lib/auth'
import { loginSchema } from '@/lib/validation'
import { rateLimit } from '@/lib/rate-limit'
import { isSupabaseConfigured } from '@/lib/supabase/config'
import { createSupabaseServerClient } from '@/lib/supabase/server'
import { mapSupabaseAuthError } from '@/lib/supabase/errors'

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local'
    const rl = rateLimit(`login:${ip}`, 10, 5 * 60_000)
    if (!rl.ok) {
      throw new ApiError(429, `Too many attempts. Try again in ${rl.retryAfterSec}s.`)
    }

    const body = await req.json()
    const input = loginSchema.parse(body)

    // ---------------- Supabase provider ----------------
    if (isSupabaseConfigured) {
      const supabase = await createSupabaseServerClient()
      const { data, error } = await supabase.auth.signInWithPassword({
        email: input.email,
        password: input.password,
      })
      if (error) throw mapSupabaseAuthError(error)

      // Session cookies are written by the server client. Ensure the local
      // profile row exists (migrates legacy same-email accounts safely).
      const identity = await ensureSupabaseProfile(data.user)
      return NextResponse.json({ user: { id: identity.id, email: identity.email, fullName: identity.fullName, avatarUrl: identity.avatarUrl } })
    }

    // ---------------- Local provider (fallback) ----------------
    const user = await db.user.findUnique({ where: { email: input.email } })
    // Generic message — do not reveal whether the email exists.
    const invalid = new ApiError(401, 'Invalid email or password.')
    if (!user || !user.passwordHash) throw invalid

    const ok = await verifyPassword(input.password, user.passwordHash)
    if (!ok) throw invalid

    await createSession(user.id)
    return NextResponse.json({
      user: { id: user.id, email: user.email, fullName: user.fullName, avatarUrl: user.avatarUrl },
    })
  } catch (e) {
    return errorResponse(e)
  }
}
