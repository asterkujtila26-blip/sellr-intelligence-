import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'
import type { AnalyticsSummary, MetricSeries } from '@/lib/types'

function buildSeries(
  metrics: { metricType: string; metricValue: number; period: string }[],
  type: string
): MetricSeries {
  const byPeriod = new Map<string, number>()
  for (const m of metrics) {
    if (m.metricType !== type) continue
    if (!byPeriod.has(m.period)) byPeriod.set(m.period, m.metricValue)
  }
  const series = [...byPeriod.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([period, value]) => ({ period, value }))
  const latest = series.length > 0 ? series[series.length - 1] : null
  const previous = series.length > 1 ? series[series.length - 2] : null
  const deltaPct =
    latest && previous && previous.value !== 0
      ? ((latest.value - previous.value) / previous.value) * 100
      : null
  return { latest, previous, deltaPct, series }
}

function healthLabel(score: number): string {
  if (score >= 75) return 'Strong'
  if (score >= 50) return 'Steady'
  if (score >= 25) return 'Needs attention'
  return 'At risk'
}

/**
 * Analytics Engine — computes the dashboard/analytics summary exclusively from
 * recorded data. Missing metrics are reported as null, never fabricated.
 * AOV is the only derived value and is explicitly labeled as an estimate.
 */
export async function GET() {
  try {
    const user = await requireUser()
    const business = await requireBusiness(user.id)

    const metrics = await db.businessMetric.findMany({
      where: { businessId: business.id },
      orderBy: [{ period: 'asc' }],
      take: 400,
    })

    const revenue = buildSeries(metrics, 'REVENUE')
    const sales = buildSeries(metrics, 'SALES')
    const customers = buildSeries(metrics, 'CUSTOMERS')
    const conversion = buildSeries(metrics, 'CONVERSION')
    const churn = buildSeries(metrics, 'CHURN')

    const metricCount = metrics.length

    // AOV = latest monthly revenue / latest monthly sales (estimate, labeled).
    let aov: AnalyticsSummary['aov'] = {
      value: null,
      note: 'Requires revenue and sales for the same period.',
    }
    if (
      revenue.latest &&
      sales.latest &&
      revenue.latest.period === sales.latest.period &&
      sales.latest.value > 0
    ) {
      aov = {
        value: revenue.latest.value / sales.latest.value,
        note: `Estimate: ${revenue.latest.period} revenue ÷ sales.`,
      }
    }

    // Goal progress from latest measured revenue, falling back to user-reported.
    const currentRevenue = revenue.latest?.value ?? business.currentMonthlyRevenue ?? null
    const goal = {
      target: business.monthlyRevenueGoal,
      current: currentRevenue,
      progressPct:
        business.monthlyRevenueGoal && business.monthlyRevenueGoal > 0 && currentRevenue != null
          ? Math.min(100, (currentRevenue / business.monthlyRevenueGoal) * 100)
          : null,
    }

    // Health score — a transparent heuristic over real inputs, or null when
    // there is nothing to score (never fabricated).
    let healthScore: AnalyticsSummary['healthScore'] = null
    if (metricCount === 0 && currentRevenue == null) {
      healthScore = null
    } else {
      const factors: string[] = []
      let score = 0

      const typesPresent = new Set(metrics.map((m) => m.metricType)).size
      const completeness = Math.min(30, typesPresent * 6)
      score += completeness
      factors.push(
        typesPresent === 0
          ? 'No recorded metrics — based on profile only'
          : `${typesPresent} metric type(s) recorded`
      )

      if (goal.target && goal.current != null) {
        const progress = Math.min(100, (goal.current / goal.target) * 100)
        score += Math.round(progress * 0.4)
        factors.push(`${Math.round(progress)}% of revenue objective`)
      } else {
        factors.push('No revenue objective set')
      }

      if (revenue.deltaPct != null) {
        const trend = Math.max(0, Math.min(30, 15 + revenue.deltaPct))
        score += Math.round(trend)
        factors.push(`Revenue trend ${revenue.deltaPct >= 0 ? '+' : ''}${revenue.deltaPct.toFixed(1)}% vs previous month`)
      } else {
        factors.push('Not enough revenue history for a trend')
      }

      score = Math.max(0, Math.min(100, score))
      healthScore = { score, label: healthLabel(score), factors }
    }

    const summary: AnalyticsSummary = {
      hasData: metricCount > 0 || currentRevenue != null,
      dataSource: 'MANUAL',
      revenue,
      sales,
      customers,
      conversion,
      churn,
      aov,
      goal,
      healthScore,
      metricCount,
    }

    return NextResponse.json({ summary, business })
  } catch (e) {
    return errorResponse(e)
  }
}
