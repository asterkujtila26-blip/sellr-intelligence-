import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireUser } from '@/lib/auth'

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const { id } = await params

    const metric = await db.businessMetric.findUnique({ where: { id } })
    if (!metric) throw new ApiError(404, 'Metric not found.')
    const business = await db.business.findUnique({ where: { id: metric.businessId } })
    if (!business || business.ownerId !== user.id) throw new ApiError(404, 'Metric not found.')

    await db.businessMetric.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
