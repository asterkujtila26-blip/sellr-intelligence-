import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'

export async function GET() {
  try {
    const user = await requireUser()
    const business = await requireBusiness(user.id)
    const recommendations = await db.recommendation.findMany({
      where: { businessId: business.id },
      orderBy: { createdAt: 'desc' },
      take: 100,
      include: { _count: { select: { tasks: true } } },
    })
    return NextResponse.json({
      recommendations: recommendations.map((r) => ({
        ...r,
        taskCount: r._count.tasks,
        _count: undefined,
      })),
    })
  } catch (e) {
    return errorResponse(e)
  }
}
