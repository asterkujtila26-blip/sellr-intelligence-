import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'
import { experimentCreateSchema } from '@/lib/validation'
import { logActivity } from '@/lib/activity'

export async function GET() {
  try {
    const user = await requireUser()
    const business = await requireBusiness(user.id)
    const experiments = await db.experiment.findMany({
      where: { businessId: business.id },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })
    return NextResponse.json({ experiments })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const business = await requireBusiness(user.id)
    const body = await req.json()
    const input = experimentCreateSchema.parse(body)

    const experiment = await db.experiment.create({
      data: {
        businessId: business.id,
        title: input.title,
        hypothesis: input.hypothesis ?? null,
        metric: input.metric ?? null,
        baselineValue: input.baselineValue ?? null,
        targetValue: input.targetValue ?? null,
        status: 'PLANNED',
      },
    })
    await logActivity(business.id, 'EXPERIMENT_CREATED', `Experiment created: "${experiment.title}"`)
    return NextResponse.json({ experiment })
  } catch (e) {
    return errorResponse(e)
  }
}
