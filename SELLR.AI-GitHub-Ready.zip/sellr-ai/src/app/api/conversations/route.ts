import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse } from '@/lib/api-helpers'
import { requireUser } from '@/lib/auth'

export async function GET() {
  try {
    const user = await requireUser()
    const conversations = await db.conversation.findMany({
      where: { userId: user.id },
      orderBy: { updatedAt: 'desc' },
      take: 50,
    })
    return NextResponse.json({ conversations })
  } catch (e) {
    return errorResponse(e)
  }
}
