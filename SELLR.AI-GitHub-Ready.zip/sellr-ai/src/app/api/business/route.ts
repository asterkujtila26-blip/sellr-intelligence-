import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireUser } from '@/lib/auth'
import { businessSchema } from '@/lib/validation'
import { logActivity } from '@/lib/activity'

export async function GET() {
  try {
    const user = await requireUser()
    const business = await db.business.findFirst({ where: { ownerId: user.id } })
    return NextResponse.json({ business })
  } catch (e) {
    return errorResponse(e)
  }
}

/** Onboarding: create the user's business (one per account). */
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const body = await req.json()
    const input = businessSchema.parse(body)

    const existing = await db.business.findFirst({ where: { ownerId: user.id } })
    if (existing) {
      throw new ApiError(409, 'Your business is already set up. Edit it in Business Profile.')
    }

    const business = await db.business.create({
      data: {
        ownerId: user.id,
        name: input.name,
        businessType: input.businessType,
        platform: input.platform ?? null,
        website: input.website ?? null,
        description: input.description ?? null,
        products: input.products ?? null,
        targetAudience: input.targetAudience ?? null,
        currentMonthlyRevenue: input.currentMonthlyRevenue ?? null,
        monthlyRevenueGoal: input.monthlyRevenueGoal ?? null,
        mainChallenge: input.mainChallenge ?? null,
        onboarded: true,
      },
    })

    await logActivity(business.id, 'ONBOARDED', `Business profile created for ${business.name}`)
    return NextResponse.json({ business })
  } catch (e) {
    return errorResponse(e)
  }
}

/** Update the business profile (Business Profile view). */
export async function PUT(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const body = await req.json()
    const input = businessSchema.parse(body)

    const business = await db.business.findFirst({ where: { ownerId: user.id } })
    if (!business) throw new ApiError(404, 'No business found. Complete onboarding first.')

    const updated = await db.business.update({
      where: { id: business.id },
      data: {
        name: input.name,
        businessType: input.businessType,
        platform: input.platform ?? null,
        website: input.website ?? null,
        description: input.description ?? null,
        products: input.products ?? null,
        targetAudience: input.targetAudience ?? null,
        currentMonthlyRevenue: input.currentMonthlyRevenue ?? null,
        monthlyRevenueGoal: input.monthlyRevenueGoal ?? null,
        mainChallenge: input.mainChallenge ?? null,
        onboarded: true,
      },
    })
    return NextResponse.json({ business: updated })
  } catch (e) {
    return errorResponse(e)
  }
}
