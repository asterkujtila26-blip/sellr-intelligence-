'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Calendar,
  Check,
  Clock,
  FlaskConical,
  ListChecks,
  ListPlus,
  Loader2,
  MoreHorizontal,
  Plus,
  Trash2,
  TrendingUp,
  X,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { apiFetch } from '@/lib/client-api'
import {
  AGENT_META,
  REC_STATUS_LABELS,
  TASK_STATUS_LABELS,
  type AgentType,
  type Experiment,
  type ExperimentStatus,
  type Priority,
  type Recommendation,
  type RecommendationStatus,
  type Task,
  type TaskStatus,
} from '@/lib/types'
import { cn } from '@/lib/utils'
import {
  AgentChip,
  EmptyState,
  PriorityBadge,
  StatusPill,
  timeAgo,
} from './shared'
import { FadeIn, Stagger, StaggerItem, springSnappy } from './motion'

// ---- Module-level constants ----

const AGENT_ORDER: AgentType[] = ['CEO', 'ANALYST', 'GROWTH', 'RETENTION', 'OPERATIONS']
const PRIORITIES: Priority[] = ['HIGH', 'MEDIUM', 'LOW']
const REC_STATUSES = Object.keys(REC_STATUS_LABELS) as RecommendationStatus[]
const TASK_STATUSES = Object.keys(TASK_STATUS_LABELS) as TaskStatus[]

const TASK_FILTERS: { value: TaskStatus | 'ALL'; label: string }[] = [
  { value: 'ALL', label: 'All' },
  { value: 'PLANNED', label: 'Planned' },
  { value: 'IN_PROGRESS', label: 'In Progress' },
  { value: 'COMPLETED', label: 'Completed' },
  { value: 'CANCELLED', label: 'Cancelled' },
]

const EXPERIMENT_STATUS_STYLES: Record<ExperimentStatus, string> = {
  PLANNED: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  RUNNING: 'bg-[#22D3EE]/10 text-[#22D3EE] border-[#22D3EE]/30',
  COMPLETED: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  CANCELLED: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/30',
}

const EXPERIMENT_STATUS_LABELS: Record<ExperimentStatus, string> = {
  PLANNED: 'Planned',
  RUNNING: 'Running',
  COMPLETED: 'Completed',
  CANCELLED: 'Cancelled',
}

type DeleteTarget = {
  kind: 'recommendation' | 'task' | 'experiment'
  id: string
  title: string
} | null

function parseNumberInput(v: string): number | null {
  const trimmed = v.trim().replace(/[$,\s]/g, '')
  if (!trimmed) return null
  const n = Number(trimmed)
  return Number.isFinite(n) ? n : null
}

function nextTaskStatus(status: TaskStatus): TaskStatus {
  switch (status) {
    case 'PLANNED':
      return 'IN_PROGRESS'
    case 'IN_PROGRESS':
      return 'COMPLETED'
    case 'COMPLETED':
      return 'PLANNED'
    case 'CANCELLED':
      return 'PLANNED'
  }
}

function isOverdue(task: Task): boolean {
  if (!task.dueDate || task.status === 'COMPLETED') return false
  const due = new Date(task.dueDate)
  const today = new Date()
  due.setHours(0, 0, 0, 0)
  today.setHours(0, 0, 0, 0)
  return due.getTime() < today.getTime()
}

function formatDueDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}

// ---- Skeletons ----

function CardSkeleton() {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-2">
        <Skeleton className="h-5 w-28" />
        <Skeleton className="h-5 w-14" />
      </div>
      <Skeleton className="mt-3 h-4 w-3/4" />
      <Skeleton className="mt-2 h-3 w-full" />
      <Skeleton className="mt-1.5 h-3 w-2/3" />
      <Skeleton className="mt-4 h-8 w-full" />
    </div>
  )
}

function CardSkeletonGrid({ count = 3 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: count }).map((_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  )
}

function RowSkeleton() {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center gap-3">
        <Skeleton className="h-6 w-6 rounded-md" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-3 w-1/3" />
        </div>
        <Skeleton className="h-5 w-16" />
      </div>
    </div>
  )
}

function RowSkeletonList({ count = 4 }: { count?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <RowSkeleton key={i} />
      ))}
    </div>
  )
}

// ---- Main view ----

export function ActionCenterView() {
  // Data
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])
  const [tasks, setTasks] = useState<Task[]>([])
  const [experiments, setExperiments] = useState<Experiment[]>([])

  // Shared mutation state
  const [deleteTarget, setDeleteTarget] = useState<DeleteTarget>(null)
  const [deleting, setDeleting] = useState(false)
  const [busyRecId, setBusyRecId] = useState<string | null>(null)
  const [convertingId, setConvertingId] = useState<string | null>(null)
  const [busyTaskId, setBusyTaskId] = useState<string | null>(null)

  // Task filters + create dialog
  const [taskFilter, setTaskFilter] = useState<TaskStatus | 'ALL'>('ALL')
  const [taskDialogOpen, setTaskDialogOpen] = useState(false)
  const [taskTitle, setTaskTitle] = useState('')
  const [taskDescription, setTaskDescription] = useState('')
  const [taskAgent, setTaskAgent] = useState<AgentType>('OPERATIONS')
  const [taskPriority, setTaskPriority] = useState<Priority>('MEDIUM')
  const [taskDueDate, setTaskDueDate] = useState('')
  const [taskError, setTaskError] = useState<string | null>(null)
  const [creatingTask, setCreatingTask] = useState(false)

  // Experiments
  const [expDialogOpen, setExpDialogOpen] = useState(false)
  const [expTitle, setExpTitle] = useState('')
  const [expHypothesis, setExpHypothesis] = useState('')
  const [expMetric, setExpMetric] = useState('')
  const [expBaseline, setExpBaseline] = useState('')
  const [expTarget, setExpTarget] = useState('')
  const [expError, setExpError] = useState<string | null>(null)
  const [creatingExp, setCreatingExp] = useState(false)
  const [resultDrafts, setResultDrafts] = useState<Record<string, string>>({})
  const [resultErrors, setResultErrors] = useState<Record<string, string>>({})
  const [savingResultId, setSavingResultId] = useState<string | null>(null)

  const loadAll = useCallback(async () => {
    setLoading(true)
    setLoadError(null)
    try {
      const [recsRes, tasksRes, expsRes] = await Promise.all([
        apiFetch<{ recommendations: Recommendation[] }>('/api/recommendations'),
        apiFetch<{ tasks: Task[] }>('/api/tasks'),
        apiFetch<{ experiments: Experiment[] }>('/api/experiments'),
      ])
      setRecommendations(recsRes.recommendations)
      setTasks(tasksRes.tasks)
      setExperiments(expsRes.experiments)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Could not load the action center.'
      setLoadError(message)
      toast.error(message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void loadAll()
  }, [loadAll])

  const refreshRecommendations = useCallback(async () => {
    try {
      const data = await apiFetch<{ recommendations: Recommendation[] }>('/api/recommendations')
      setRecommendations(data.recommendations)
    } catch {
      // Silent refresh — primary action already succeeded.
    }
  }, [])

  const filteredTasks = useMemo(() => {
    if (taskFilter === 'ALL') return tasks
    return tasks.filter((t) => t.status === taskFilter)
  }, [tasks, taskFilter])

  // ---- Recommendation actions ----

  async function updateRecommendationStatus(rec: Recommendation, status: RecommendationStatus) {
    if (rec.status === status) return
    setBusyRecId(rec.id)
    try {
      const data = await apiFetch<{ recommendation: Recommendation }>(
        `/api/recommendations/${rec.id}`,
        { method: 'PATCH', body: JSON.stringify({ status }) }
      )
      setRecommendations((prev) =>
        prev.map((r) => (r.id === rec.id ? { ...r, ...data.recommendation, taskCount: r.taskCount } : r))
      )
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not update the recommendation.')
    } finally {
      setBusyRecId(null)
    }
  }

  async function convertToTask(rec: Recommendation) {
    setConvertingId(rec.id)
    try {
      const created = await apiFetch<{ task: Task }>('/api/tasks', {
        method: 'POST',
        body: JSON.stringify({
          title: rec.title,
          description: rec.description,
          recommendationId: rec.id,
          assignedAgent: rec.agentType,
          priority: rec.priority,
        }),
      })
      setTasks((prev) => [created.task, ...prev])
      try {
        await apiFetch<{ recommendation: Recommendation }>(`/api/recommendations/${rec.id}`, {
          method: 'PATCH',
          body: JSON.stringify({ status: 'PLANNED' }),
        })
        setRecommendations((prev) =>
          prev.map((r) =>
            r.id === rec.id ? { ...r, status: 'PLANNED' as const, taskCount: (r.taskCount ?? 0) + 1 } : r
          )
        )
      } catch {
        // Task exists — surface the recommendation status failure quietly but refresh truth.
        void refreshRecommendations()
      }
      toast.success('Task created from recommendation')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not create the task.')
    } finally {
      setConvertingId(null)
    }
  }

  // ---- Task actions ----

  function openTaskDialog() {
    setTaskTitle('')
    setTaskDescription('')
    setTaskAgent('OPERATIONS')
    setTaskPriority('MEDIUM')
    setTaskDueDate('')
    setTaskError(null)
    setTaskDialogOpen(true)
  }

  async function createTask() {
    setTaskError(null)
    if (!taskTitle.trim()) {
      setTaskError('Title is required.')
      return
    }
    const dueIso = taskDueDate ? new Date(`${taskDueDate}T00:00:00`).toISOString() : null
    setCreatingTask(true)
    try {
      const data = await apiFetch<{ task: Task }>('/api/tasks', {
        method: 'POST',
        body: JSON.stringify({
          title: taskTitle.trim(),
          description: taskDescription.trim() || undefined,
          assignedAgent: taskAgent,
          priority: taskPriority,
          dueDate: dueIso,
        }),
      })
      setTasks((prev) => [data.task, ...prev])
      setTaskDialogOpen(false)
      toast.success('Task created')
    } catch (err) {
      setTaskError(err instanceof Error ? err.message : 'Could not create the task.')
    } finally {
      setCreatingTask(false)
    }
  }

  async function updateTaskStatus(task: Task, status: TaskStatus) {
    if (task.status === status) return
    setBusyTaskId(task.id)
    try {
      const data = await apiFetch<{ task: Task }>(`/api/tasks/${task.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      })
      setTasks((prev) => prev.map((t) => (t.id === task.id ? data.task : t)))
      if (status === 'COMPLETED') toast.success('Task completed')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not update the task.')
    } finally {
      setBusyTaskId(null)
    }
  }

  // ---- Experiment actions ----

  function openExperimentDialog() {
    setExpTitle('')
    setExpHypothesis('')
    setExpMetric('')
    setExpBaseline('')
    setExpTarget('')
    setExpError(null)
    setExpDialogOpen(true)
  }

  async function createExperiment() {
    setExpError(null)
    if (!expTitle.trim()) {
      setExpError('Title is required.')
      return
    }
    const baseline = expBaseline.trim() ? parseNumberInput(expBaseline) : null
    const target = expTarget.trim() ? parseNumberInput(expTarget) : null
    if (expBaseline.trim() && baseline == null) {
      setExpError('Baseline value must be a number.')
      return
    }
    if (expTarget.trim() && target == null) {
      setExpError('Target value must be a number.')
      return
    }
    setCreatingExp(true)
    try {
      const data = await apiFetch<{ experiment: Experiment }>('/api/experiments', {
        method: 'POST',
        body: JSON.stringify({
          title: expTitle.trim(),
          hypothesis: expHypothesis.trim() || undefined,
          metric: expMetric.trim() || undefined,
          baselineValue: baseline,
          targetValue: target,
        }),
      })
      setExperiments((prev) => [data.experiment, ...prev])
      setExpDialogOpen(false)
      toast.success('Experiment created')
    } catch (err) {
      setExpError(err instanceof Error ? err.message : 'Could not create the experiment.')
    } finally {
      setCreatingExp(false)
    }
  }

  async function patchExperiment(
    exp: Experiment,
    body: { status: ExperimentStatus; resultValue?: number }
  ): Promise<boolean> {
    try {
      const data = await apiFetch<{ experiment: Experiment }>(`/api/experiments/${exp.id}`, {
        method: 'PATCH',
        body: JSON.stringify(body),
      })
      setExperiments((prev) => prev.map((e) => (e.id === exp.id ? data.experiment : e)))
      return true
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not update the experiment.')
      return false
    }
  }

  async function handleExperimentStatusChange(exp: Experiment, status: ExperimentStatus) {
    if (status === exp.status) return
    if (status === 'COMPLETED' && exp.resultValue == null) {
      // Ask for the result value first, then PATCH once with both fields.
      setResultDrafts((prev) => ({ ...prev, [exp.id]: prev[exp.id] ?? '' }))
      setResultErrors((prev) => {
        const next = { ...prev }
        delete next[exp.id]
        return next
      })
      return
    }
    const ok = await patchExperiment(exp, { status })
    if (ok && status === 'COMPLETED') toast.success('Experiment completed')
  }

  async function saveExperimentResult(exp: Experiment) {
    const draft = resultDrafts[exp.id] ?? ''
    const value = draft.trim() ? parseNumberInput(draft) : NaN
    if (value == null || !Number.isFinite(value)) {
      setResultErrors((prev) => ({ ...prev, [exp.id]: 'Enter a numeric result value.' }))
      return
    }
    setSavingResultId(exp.id)
    const ok = await patchExperiment(exp, { status: 'COMPLETED', resultValue: value })
    setSavingResultId(null)
    if (ok) {
      setResultDrafts((prev) => {
        const next = { ...prev }
        delete next[exp.id]
        return next
      })
      setResultErrors((prev) => {
        const next = { ...prev }
        delete next[exp.id]
        return next
      })
      toast.success('Experiment completed')
    }
  }

  // ---- Deletion (shared confirm dialog) ----

  async function confirmDelete() {
    if (!deleteTarget) return
    const { kind, id } = deleteTarget
    setDeleting(true)
    try {
      const endpoints: Record<Exclude<DeleteTarget, null>['kind'], string> = {
        recommendation: '/api/recommendations',
        task: '/api/tasks',
        experiment: '/api/experiments',
      }
      await apiFetch<{ ok: boolean }>(`${endpoints[kind]}/${id}`, { method: 'DELETE' })
      if (kind === 'recommendation') {
        setRecommendations((prev) => prev.filter((r) => r.id !== id))
        toast.success('Recommendation deleted')
      } else if (kind === 'task') {
        const deleted = tasks.find((t) => t.id === id)
        setTasks((prev) => prev.filter((t) => t.id !== id))
        if (deleted?.recommendationId) void refreshRecommendations()
        toast.success('Task deleted')
      } else {
        setExperiments((prev) => prev.filter((e) => e.id !== id))
        setResultDrafts((prev) => {
          const next = { ...prev }
          delete next[id]
          return next
        })
        toast.success('Experiment deleted')
      }
      setDeleteTarget(null)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not delete the item.')
    } finally {
      setDeleting(false)
    }
  }

  // ---- Render helpers ----

  function renderDeleteMenu(
    kind: 'recommendation' | 'task' | 'experiment',
    id: string,
    title: string
  ) {
    return (
      <DropdownMenuItem
        variant="destructive"
        onSelect={() => setDeleteTarget({ kind, id, title })}
      >
        <Trash2 aria-hidden />
        Delete
      </DropdownMenuItem>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <FadeIn>
        <h1 className="text-2xl font-semibold tracking-tight">Action Center</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Recommendations from your AI team, turned into execution.
        </p>
      </FadeIn>

      {loadError && !loading ? (
        <div
          role="alert"
          className="flex flex-col gap-3 rounded-xl border border-destructive/30 bg-destructive/10 p-4 sm:flex-row sm:items-center sm:justify-between"
        >
          <p className="text-sm text-destructive">{loadError}</p>
          <Button size="sm" variant="outline" onClick={() => void loadAll()}>
            Try again
          </Button>
        </div>
      ) : null}

      <Tabs defaultValue="recommendations">
        <TabsList aria-label="Action center sections">
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="experiments">Experiments</TabsTrigger>
        </TabsList>

        {/* ------------------------------ Recommendations ------------------------------ */}
        <TabsContent value="recommendations" className="mt-4 space-y-4">
          {loading ? (
            <CardSkeletonGrid />
          ) : recommendations.length === 0 ? (
            <EmptyState
              icon={ListChecks}
              title="No recommendations yet"
              description="When you chat with your AI business team, agents add recommendations here. Review them, convert the good ones into tasks, and track execution."
            />
          ) : (
            <Stagger className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              {recommendations.map((rec) => {
                const taskCount = rec.taskCount ?? 0
                return (
                  <StaggerItem key={rec.id} className="h-full">
                    <article
                      className="flex h-full flex-col gap-3 rounded-xl border border-border bg-card p-5"
                    >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <AgentChip agent={rec.agentType} />
                        <PriorityBadge priority={rec.priority} />
                      </div>
                      <div className="flex items-center gap-1">
                        <StatusPill status={rec.status} kind="recommendation" />
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 shrink-0 text-muted-foreground"
                              aria-label={`Actions for recommendation: ${rec.title}`}
                            >
                              <MoreHorizontal className="h-4 w-4" aria-hidden />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {renderDeleteMenu('recommendation', rec.id, rec.title)}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>

                    <div className="min-w-0">
                      <p className="text-sm font-medium leading-snug">{rec.title}</p>
                      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                        {rec.description}
                      </p>
                    </div>

                    {rec.expectedImpact ? (
                      <p className="flex items-start gap-1.5 text-xs text-emerald-400">
                        <TrendingUp className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                        {rec.expectedImpact}
                      </p>
                    ) : null}

                    <div className="mt-auto space-y-3 pt-1">
                      <div className="flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
                        <span>{timeAgo(rec.createdAt)}</span>
                        {taskCount > 0 ? (
                          <span>
                            {taskCount} linked task{taskCount === 1 ? '' : 's'}
                          </span>
                        ) : null}
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <Select
                          value={rec.status}
                          onValueChange={(v) => void updateRecommendationStatus(rec, v as RecommendationStatus)}
                        >
                          <SelectTrigger
                            size="sm"
                            className="min-w-32 flex-1"
                            disabled={busyRecId === rec.id}
                            aria-label={`Status for ${rec.title}`}
                          >
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {REC_STATUSES.map((s) => (
                              <SelectItem key={s} value={s}>
                                {REC_STATUS_LABELS[s]}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {taskCount === 0 ? (
                          <Button
                            size="sm"
                            variant="secondary"
                            className="h-8"
                            onClick={() => void convertToTask(rec)}
                            disabled={convertingId === rec.id}
                          >
                            {convertingId === rec.id ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                            ) : (
                              <ListPlus className="h-3.5 w-3.5" aria-hidden />
                            )}
                            Convert to task
                          </Button>
                        ) : null}
                      </div>
                    </div>
                  </article>
                  </StaggerItem>
                )
              })}
            </Stagger>
          )}
        </TabsContent>

        {/* ------------------------------------ Tasks ------------------------------------ */}
        <TabsContent value="tasks" className="mt-4 space-y-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div
              className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-slim sm:pb-0"
              role="group"
              aria-label="Filter tasks by status"
            >
              {TASK_FILTERS.map((f) => (
                <button
                  key={f.value}
                  type="button"
                  onClick={() => setTaskFilter(f.value)}
                  aria-pressed={taskFilter === f.value}
                  className={cn(
                    'relative h-9 shrink-0 rounded-lg border px-3 text-xs font-medium transition-colors active:scale-[0.97]',
                    taskFilter === f.value
                      ? 'border-transparent text-primary'
                      : 'border-border bg-card text-muted-foreground hover:bg-accent hover:text-foreground'
                  )}
                >
                  {/* Sliding active pill — shared layout transition */}
                  {taskFilter === f.value ? (
                    <motion.span
                      layoutId="task-filter-pill"
                      className="absolute inset-0 rounded-lg border border-primary/40 bg-primary/10"
                      transition={springSnappy}
                      aria-hidden
                    />
                  ) : null}
                  <span className="relative z-10">{f.label}</span>
                </button>
              ))}
            </div>
            <Button size="sm" className="h-9 shrink-0" onClick={openTaskDialog}>
              <Plus className="h-4 w-4" aria-hidden />
              New task
            </Button>
          </div>

          {loading ? (
            <RowSkeletonList />
          ) : tasks.length === 0 ? (
            <EmptyState
              icon={ListChecks}
              title="No tasks yet"
              description="Create a task manually or convert a recommendation into a task. Tasks are where your AI team's advice becomes execution."
            >
              <Button size="sm" onClick={openTaskDialog}>
                <Plus className="h-4 w-4" aria-hidden />
                New task
              </Button>
            </EmptyState>
          ) : filteredTasks.length === 0 ? (
            <EmptyState
              icon={ListChecks}
              title="Nothing here"
              description={`No ${TASK_FILTERS.find((f) => f.value === taskFilter)?.label.toLowerCase()} tasks. Try another filter.`}
            />
          ) : (
            <Stagger className="space-y-3">
              {filteredTasks.map((task) => {
                const overdue = isOverdue(task)
                const completed = task.status === 'COMPLETED'
                const next = nextTaskStatus(task.status)
                return (
                  <StaggerItem key={task.id}>
                    <article
                      className="rounded-xl border border-border bg-card p-4"
                    >
                    <div className="flex items-start gap-3">
                      {/* Checkbox-style status advance button */}
                      <button
                        type="button"
                        onClick={() => void updateTaskStatus(task, next)}
                        disabled={busyTaskId === task.id}
                        aria-label={`${TASK_STATUS_LABELS[task.status]}. Click to mark as ${TASK_STATUS_LABELS[next]}`}
                        className={cn(
                          'mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md border transition-colors disabled:opacity-60',
                          completed
                            ? 'border-emerald-500/50 bg-emerald-500/20 text-emerald-400'
                            : task.status === 'IN_PROGRESS'
                              ? 'border-[#22D3EE]/50 bg-[#22D3EE]/15 text-[#22D3EE]'
                              : 'border-border text-transparent hover:border-primary/50 hover:text-primary/40'
                        )}
                      >
                        {completed ? (
                          <Check className="h-4 w-4" aria-hidden />
                        ) : task.status === 'IN_PROGRESS' ? (
                          <Clock className="h-4 w-4" aria-hidden />
                        ) : null}
                      </button>

                      <div className="min-w-0 flex-1">
                        <p
                          className={cn(
                            'text-sm font-medium leading-snug',
                            completed && 'text-muted-foreground line-through'
                          )}
                        >
                          {task.title}
                        </p>
                        {task.description ? (
                          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                            {task.description}
                          </p>
                        ) : null}
                        <div className="mt-2 flex flex-wrap items-center gap-2">
                          <PriorityBadge priority={task.priority} />
                          <AgentChip agent={task.assignedAgent} />
                          {task.dueDate ? (
                            <span
                              className={cn(
                                'inline-flex items-center gap-1 text-[11px]',
                                overdue ? 'font-medium text-red-400' : 'text-muted-foreground'
                              )}
                            >
                              <Calendar className="h-3 w-3" aria-hidden />
                              {formatDueDate(task.dueDate)}
                              {overdue ? ' · overdue' : ''}
                            </span>
                          ) : null}
                          {task.completedAt ? (
                            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400">
                              <Check className="h-3 w-3" aria-hidden />
                              Completed {timeAgo(task.completedAt)}
                            </span>
                          ) : null}
                        </div>
                      </div>

                      <div className="flex shrink-0 items-center gap-1">
                        <StatusPill status={task.status} kind="task" />
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground"
                              aria-label={`Actions for task: ${task.title}`}
                            >
                              <MoreHorizontal className="h-4 w-4" aria-hidden />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {TASK_STATUSES.filter((s) => s !== task.status).map((s) => (
                              <DropdownMenuItem
                                key={s}
                                onSelect={() => void updateTaskStatus(task, s)}
                              >
                                {s === 'COMPLETED'
                                  ? 'Mark completed'
                                  : s === 'PLANNED' && task.status !== 'PLANNED'
                                    ? 'Reopen'
                                    : `Mark ${TASK_STATUS_LABELS[s].toLowerCase()}`}
                              </DropdownMenuItem>
                            ))}
                            <DropdownMenuSeparator />
                            {renderDeleteMenu('task', task.id, task.title)}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </article>
                  </StaggerItem>
                )
              })}
            </Stagger>
          )}
        </TabsContent>

        {/* --------------------------------- Experiments --------------------------------- */}
        <TabsContent value="experiments" className="mt-4 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <p className="text-sm text-muted-foreground">
              {experiments.length > 0
                ? `${experiments.length} experiment${experiments.length === 1 ? '' : 's'} in the loop.`
                : 'Test one change at a time and record the result.'}
            </p>
            <Button size="sm" className="h-9 shrink-0" onClick={openExperimentDialog}>
              <Plus className="h-4 w-4" aria-hidden />
              New experiment
            </Button>
          </div>

          {loading ? (
            <CardSkeletonGrid />
          ) : experiments.length === 0 ? (
            <EmptyState
              icon={FlaskConical}
              title="No experiments yet"
              description="Run growth experiments with a clear hypothesis and metric. Mark an experiment completed to record what actually happened."
            >
              <Button size="sm" onClick={openExperimentDialog}>
                <Plus className="h-4 w-4" aria-hidden />
                New experiment
              </Button>
            </EmptyState>
          ) : (
            <Stagger className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {experiments.map((exp) => {
                const pendingResult = resultDrafts[exp.id] !== undefined
                const statusValue = pendingResult ? 'COMPLETED' : exp.status
                const fmtNum = (v: number | null) =>
                  v == null ? '—' : v.toLocaleString('en-US')
                return (
                  <StaggerItem key={exp.id} className="h-full">
                    <article
                      className="flex h-full flex-col gap-3 rounded-xl border border-border bg-card p-5"
                    >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-medium leading-snug">{exp.title}</p>
                        {exp.hypothesis ? (
                          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                            {exp.hypothesis}
                          </p>
                        ) : null}
                      </div>
                      <div className="flex shrink-0 items-center gap-1.5">
                        <span
                          className={cn(
                            'inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium',
                            EXPERIMENT_STATUS_STYLES[exp.status]
                          )}
                        >
                          {EXPERIMENT_STATUS_LABELS[exp.status]}
                        </span>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground"
                              aria-label={`Actions for experiment: ${exp.title}`}
                            >
                              <MoreHorizontal className="h-4 w-4" aria-hidden />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {renderDeleteMenu('experiment', exp.id, exp.title)}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      {exp.metric ? (
                        <span className="inline-flex items-center gap-1">
                          <FlaskConical className="h-3 w-3" aria-hidden />
                          {exp.metric}
                        </span>
                      ) : null}
                      <span>
                        Baseline {fmtNum(exp.baselineValue)} → Target {fmtNum(exp.targetValue)}
                      </span>
                      {exp.resultValue != null ? (
                        <span className="font-medium text-emerald-400">
                          Result: {exp.resultValue.toLocaleString('en-US')}
                        </span>
                      ) : null}
                      <span className="ml-auto">{timeAgo(exp.createdAt)}</span>
                    </div>

                    <div className="mt-auto space-y-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <Select
                          value={statusValue}
                          onValueChange={(v) =>
                            void handleExperimentStatusChange(exp, v as ExperimentStatus)
                          }
                        >
                          <SelectTrigger
                            size="sm"
                            className={cn('min-w-32 flex-1', pendingResult && 'border-emerald-500/40')}
                            aria-label={`Status for ${exp.title}`}
                          >
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {(Object.keys(EXPERIMENT_STATUS_LABELS) as ExperimentStatus[]).map((s) => (
                              <SelectItem key={s} value={s}>
                                {EXPERIMENT_STATUS_LABELS[s]}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {pendingResult ? (
                        <div className="rounded-lg border border-border bg-secondary/50 p-3">
                          <Label
                            htmlFor={`result-${exp.id}`}
                            className="text-xs text-muted-foreground"
                          >
                            Record the result value before completing
                          </Label>
                          <div className="mt-2 flex items-center gap-2">
                            <Input
                              id={`result-${exp.id}`}
                              inputMode="decimal"
                              className="h-8 flex-1"
                              value={resultDrafts[exp.id] ?? ''}
                              placeholder="Measured value"
                              autoFocus
                              onChange={(e) =>
                                setResultDrafts((prev) => ({ ...prev, [exp.id]: e.target.value }))
                              }
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') void saveExperimentResult(exp)
                              }}
                            />
                            <Button
                              size="sm"
                              className="h-8"
                              onClick={() => void saveExperimentResult(exp)}
                              disabled={savingResultId === exp.id}
                            >
                              {savingResultId === exp.id ? (
                                <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                              ) : (
                                <Check className="h-3.5 w-3.5" aria-hidden />
                              )}
                              Save result
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground"
                              aria-label="Cancel recording result"
                              onClick={() =>
                                setResultDrafts((prev) => {
                                  const next = { ...prev }
                                  delete next[exp.id]
                                  return next
                                })
                              }
                            >
                              <X className="h-4 w-4" aria-hidden />
                            </Button>
                          </div>
                          {resultErrors[exp.id] ? (
                            <p role="alert" className="mt-1.5 text-xs text-destructive">
                              {resultErrors[exp.id]}
                            </p>
                          ) : null}
                        </div>
                      ) : null}
                    </div>
                  </article>
                  </StaggerItem>
                )
              })}
            </Stagger>
          )}
        </TabsContent>
      </Tabs>

      {/* New task dialog */}
      <Dialog open={taskDialogOpen} onOpenChange={setTaskDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>New task</DialogTitle>
            <DialogDescription>
              Assign work to one of your agents and track it to done.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="taskTitle">Title *</Label>
              <Input
                id="taskTitle"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                placeholder="e.g. Rewrite product page headline"
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="taskDescription">Description</Label>
              <Textarea
                id="taskDescription"
                value={taskDescription}
                onChange={(e) => setTaskDescription(e.target.value)}
                placeholder="Context, links, acceptance criteria…"
                rows={3}
                maxLength={1000}
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Assigned agent</Label>
                <Select value={taskAgent} onValueChange={(v) => setTaskAgent(v as AgentType)}>
                  <SelectTrigger className="w-full" aria-label="Assigned agent">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {AGENT_ORDER.map((a) => (
                      <SelectItem key={a} value={a}>
                        {AGENT_META[a].name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Priority</Label>
                <Select value={taskPriority} onValueChange={(v) => setTaskPriority(v as Priority)}>
                  <SelectTrigger className="w-full" aria-label="Task priority">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PRIORITIES.map((p) => (
                      <SelectItem key={p} value={p}>
                        {p}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="taskDue">Due date</Label>
              <Input
                id="taskDue"
                type="date"
                value={taskDueDate}
                onChange={(e) => setTaskDueDate(e.target.value)}
              />
            </div>
            {taskError ? (
              <p role="alert" className="text-xs text-destructive">
                {taskError}
              </p>
            ) : null}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setTaskDialogOpen(false)} disabled={creatingTask}>
              Cancel
            </Button>
            <Button onClick={() => void createTask()} disabled={creatingTask}>
              {creatingTask ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <Plus className="h-4 w-4" aria-hidden />
              )}
              Create task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New experiment dialog */}
      <Dialog open={expDialogOpen} onOpenChange={setExpDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>New experiment</DialogTitle>
            <DialogDescription>
              State a hypothesis and the metric you will move. Record the result when it ends.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="expTitle">Title *</Label>
              <Input
                id="expTitle"
                value={expTitle}
                onChange={(e) => setExpTitle(e.target.value)}
                placeholder="e.g. Bundle pricing test on landing page"
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="expHypothesis">Hypothesis</Label>
              <Textarea
                id="expHypothesis"
                value={expHypothesis}
                onChange={(e) => setExpHypothesis(e.target.value)}
                placeholder="e.g. If we show a 3-tier bundle, average order value increases by 15%."
                rows={2}
                maxLength={600}
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-1.5 sm:col-span-3">
                <Label htmlFor="expMetric">Metric</Label>
                <Input
                  id="expMetric"
                  value={expMetric}
                  onChange={(e) => setExpMetric(e.target.value)}
                  placeholder="e.g. Checkout conversion rate"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="expBaseline">Baseline value</Label>
                <Input
                  id="expBaseline"
                  inputMode="decimal"
                  value={expBaseline}
                  onChange={(e) => setExpBaseline(e.target.value)}
                  placeholder="e.g. 2.4"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="expTarget">Target value</Label>
                <Input
                  id="expTarget"
                  inputMode="decimal"
                  value={expTarget}
                  onChange={(e) => setExpTarget(e.target.value)}
                  placeholder="e.g. 3.0"
                />
              </div>
            </div>
            {expError ? (
              <p role="alert" className="text-xs text-destructive">
                {expError}
              </p>
            ) : null}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setExpDialogOpen(false)} disabled={creatingExp}>
              Cancel
            </Button>
            <Button onClick={() => void createExperiment()} disabled={creatingExp}>
              {creatingExp ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <FlaskConical className="h-4 w-4" aria-hidden />
              )}
              Create experiment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Shared delete confirmation */}
      <AlertDialog
        open={deleteTarget !== null}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null)
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete{' '}
              {deleteTarget?.kind === 'recommendation'
                ? 'recommendation'
                : deleteTarget?.kind === 'task'
                  ? 'task'
                  : 'experiment'}
              ?
            </AlertDialogTitle>
            <AlertDialogDescription>
              “{deleteTarget?.title}” will be permanently removed. Linked records stay intact, but
              this item cannot be recovered.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault()
                void confirmDelete()
              }}
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={deleting}
            >
              {deleting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
