'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { useSellr, type View } from '@/store/sellr-store'
import { LandingView } from './landing-view'
import { AuthView } from './auth-view'
import { OnboardingView } from './onboarding-view'
import { AppShell } from './app-shell'
import { DashboardView } from './dashboard-view'
import { TeamView } from './team-view'
import { ActionCenterView } from './action-center-view'
import { AnalyticsView } from './analytics-view'
import { BusinessView } from './business-view'
import { PageTransition, EASE_OUT } from './motion'
import { isSupabaseConfigured } from '@/lib/supabase/config'

function Splash() {
  return (
    <div className="flex min-h-screen items-center justify-center sellr-backdrop">
      <motion.div
        className="flex flex-col items-center gap-4"
        initial={{ opacity: 0, scale: 0.92 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.45, ease: EASE_OUT }}
      >
        <div className="relative">
          {/* Pulsing brand ring behind the logo mark */}
          <span
            className="animate-ring-pulse absolute inset-0 rounded-xl bg-primary/40"
            aria-hidden
          />
          <div className="relative flex h-12 w-12 items-center justify-center rounded-xl border border-primary/40 bg-primary text-primary-foreground shadow-[0_6px_30px_rgba(255,78,0,0.5)]">
            <span className="text-xl font-black leading-none">S</span>
          </div>
        </div>
        <div className="flex items-center gap-1.5" aria-hidden>
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="animate-bounce-dot h-1.5 w-1.5 rounded-full bg-primary"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
        <p className="text-xs text-muted-foreground">Waking up your AI business team…</p>
      </motion.div>
    </div>
  )
}

type AppScreenState = Exclude<View, 'landing' | 'auth' | 'forgot' | 'reset' | 'verify' | 'onboarding'>

function AppView({ view }: { view: AppScreenState }) {
  switch (view) {
    case 'team':
      return <TeamView />
    case 'actions':
      return <ActionCenterView />
    case 'analytics':
      return <AnalyticsView />
    case 'business':
      return <BusinessView />
    case 'dashboard':
    default:
      return <DashboardView />
  }
}

/**
 * React to auth events emitted by the Supabase browser client. This keeps the
 * UI in sync when a session is revoked (e.g. signed out in another tab).
 */
function useAuthStateListener() {
  const provider = useSellr((s) => s.provider)
  useEffect(() => {
    if (!isSupabaseConfigured) return
    let unsubscribe: (() => void) | undefined
    let active = true

    void (async () => {
      try {
        const { createSupabaseBrowserClient } = await import('@/lib/supabase/client')
        if (!active) return
        const supabase = createSupabaseBrowserClient()
        const { data } = supabase.auth.onAuthStateChange((event) => {
          if (event === 'SIGNED_OUT') {
            useSellr.setState({ user: null, business: null, view: 'landing' })
          }
          if (event === 'USER_UPDATED') {
            // e.g. password changed / email confirmed — refresh identity.
            void useSellr.getState().bootstrap()
          }
        })
        unsubscribe = () => data.subscription.unsubscribe()
      } catch {
        // Supabase configured but unreachable — bootstrap fallbacks still work.
      }
    })()

    return () => {
      active = false
      unsubscribe?.()
    }
  }, [provider])
}

/**
 * Consume auth-related URL parameters (email action callbacks) exactly once,
 * then clean them from the address bar.
 */
function useAuthUrlParams() {
  useEffect(() => {
    if (typeof window === 'undefined') return
    const url = new URL(window.location.href)
    const resetToken = url.searchParams.get('reset')
    const authError = url.searchParams.get('auth_error')
    const next = url.searchParams.get('next')

    if (resetToken) {
      useSellr.setState({ resetToken, authNotice: null, urlDriven: true, view: 'reset' })
      url.searchParams.delete('reset')
    } else if (next && next.startsWith('/reset')) {
      // Supabase recovery redirect — session established by /auth/callback.
      useSellr.setState({ urlDriven: true, view: 'reset' })
      url.searchParams.delete('next')
    } else if (authError) {
      useSellr.setState({
        authNotice: { kind: 'error', message: authError },
        urlDriven: true,
        view: 'auth',
      })
      url.searchParams.delete('auth_error')
    } else {
      return
    }

    window.history.replaceState({}, '', url.pathname + (url.searchParams.toString() ? `?${url.searchParams}` : ''))
  }, [])
}

type TopLevel = 'landing' | 'auth' | 'onboarding' | 'app'

function topLevelOf(view: View): TopLevel {
  if (view === 'landing') return 'landing'
  if (view === 'onboarding') return 'onboarding'
  if (view === 'auth' || view === 'forgot' || view === 'reset' || view === 'verify') return 'auth'
  return 'app'
}

export function SellrApp() {
  const { booted, view, provider, bootstrap } = useSellr()

  useAuthUrlParams()
  useAuthStateListener()

  useEffect(() => {
    void bootstrap()
  }, [bootstrap])

  if (!booted) return <Splash />

  const level = topLevelOf(view)

  const content =
    level === 'landing' ? (
      <LandingView />
    ) : level === 'auth' ? (
      <AuthView provider={provider} />
    ) : level === 'onboarding' ? (
      <OnboardingView />
    ) : (
      <AppShell>
        <AppView view={view as AppScreenState} />
      </AppShell>
    )

  return (
    <PageTransition pageKey={level} className="min-h-screen">
      {content}
    </PageTransition>
  )
}
