'use client'

import { Crown, LineChart, TrendingUp, Users, Workflow } from 'lucide-react'
import { cn } from '@/lib/utils'
import {
  AGENT_META,
  PRIORITY_STYLES,
  type AgentType,
  type Priority,
  type RecommendationStatus,
  type TaskStatus,
  REC_STATUS_LABELS,
  TASK_STATUS_LABELS,
} from '@/lib/types'

const AGENT_ICONS: Record<AgentType, typeof Crown> = {
  CEO: Crown,
  ANALYST: LineChart,
  GROWTH: TrendingUp,
  RETENTION: Users,
  OPERATIONS: Workflow,
}

/** SELLR brand mark — orange rounded square with a bold S. */
export function SellrLogo({
  className,
  showWordmark = true,
  wordmarkClassName,
}: {
  className?: string
  showWordmark?: boolean
  wordmarkClassName?: string
}) {
  return (
    <div className="flex items-center gap-2">
      <div
        className={cn(
          'flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-[0_2px_12px_rgba(255,78,0,0.45)]',
          className
        )}
      >
        <span className="text-sm font-black leading-none">S</span>
      </div>
      {showWordmark ? (
        <span className={cn('text-sm font-bold tracking-tight', wordmarkClassName)}>
          SELLR
        </span>
      ) : null}
    </div>
  )
}

export function AgentIcon({
  agent,
  className,
}: {
  agent: AgentType
  className?: string
}) {
  const Icon = AGENT_ICONS[agent]
  return <Icon className={cn('h-4 w-4', AGENT_META[agent].color, className)} aria-hidden />
}

export function AgentChip({ agent, className }: { agent: AgentType; className?: string }) {
  const meta = AGENT_META[agent]
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium',
        meta.bg,
        meta.border,
        meta.color,
        className
      )}
    >
      <AgentIcon agent={agent} className="h-3 w-3" />
      {meta.name}
    </span>
  )
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium tracking-wide',
        PRIORITY_STYLES[priority]
      )}
    >
      {priority}
    </span>
  )
}

const REC_STATUS_STYLES: Record<RecommendationStatus, string> = {
  SUGGESTED: 'bg-[#FF5A1F]/10 text-[#FF6A33] border-[#FF5A1F]/30',
  PLANNED: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  IN_PROGRESS: 'bg-[#22D3EE]/10 text-[#22D3EE] border-[#22D3EE]/30',
  COMPLETED: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  CANCELLED: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/30',
}

const TASK_STATUS_STYLES: Record<TaskStatus, string> = {
  PLANNED: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  IN_PROGRESS: 'bg-[#22D3EE]/10 text-[#22D3EE] border-[#22D3EE]/30',
  COMPLETED: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  CANCELLED: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/30',
}

export function StatusPill({
  status,
  kind = 'recommendation',
}: {
  status: RecommendationStatus | TaskStatus
  kind?: 'recommendation' | 'task'
}) {
  const styles = kind === 'task' ? TASK_STATUS_STYLES : REC_STATUS_STYLES
  const label =
    kind === 'task'
      ? TASK_STATUS_LABELS[status as TaskStatus]
      : REC_STATUS_LABELS[status as RecommendationStatus]
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium',
        styles[status as never]
      )}
    >
      {label}
    </span>
  )
}

export function SectionTitle({
  title,
  hint,
  children,
}: {
  title: string
  hint?: string
  children?: React.ReactNode
}) {
  return (
    <div className="flex items-end justify-between gap-3">
      <div>
        <h2 className="text-sm font-semibold tracking-tight text-foreground">{title}</h2>
        {hint ? <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p> : null}
      </div>
      {children}
    </div>
  )
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>
  title: string
  description: string
  children?: React.ReactNode
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-secondary/40 px-6 py-10 text-center">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
        <Icon className="h-5 w-5 text-muted-foreground" aria-hidden />
      </div>
      <p className="mt-3 text-sm font-medium text-foreground">{title}</p>
      <p className="mt-1 max-w-sm text-xs leading-relaxed text-muted-foreground">{description}</p>
      {children ? <div className="mt-4">{children}</div> : null}
    </div>
  )
}

export function formatMoney(value: number, compact = true): string {
  if (compact && Math.abs(value) >= 1_000_000) {
    const m = value / 1_000_000
    return `$${m % 1 === 0 ? m : m.toFixed(1)}M`
  }
  if (compact && Math.abs(value) >= 10_000) {
    const k = value / 1000
    return `$${k % 1 === 0 ? k : k.toFixed(1)}k`
  }
  return value.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: value % 1 === 0 ? 0 : 2,
  })
}

export function formatMetricValue(type: string, value: number, compact = true): string {
  switch (type) {
    case 'REVENUE':
    case 'AOV':
      return formatMoney(value, compact)
    case 'CONVERSION':
    case 'CHURN':
      return `${value}%`
    default:
      return value.toLocaleString('en-US')
  }
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60_000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  if (days < 30) return `${days}d ago`
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}
