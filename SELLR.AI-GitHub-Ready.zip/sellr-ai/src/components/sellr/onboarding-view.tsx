'use client'

import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowLeft, ArrowRight, Building2, Loader2, Package, Target } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useSellr } from '@/store/sellr-store'
import { apiFetch } from '@/lib/client-api'
import type { Business } from '@/lib/types'
import { cn } from '@/lib/utils'
import { EASE_OUT, springSnappy } from './motion'

const BUSINESS_TYPES = [
  'Digital Products',
  'SaaS',
  'Community / Membership',
  'Coaching / Consulting',
  'E-commerce',
  'Agency / Services',
  'Content / Creator',
  'Other',
]

const STEPS = [
  { title: 'Business basics', icon: Building2, fields: 'Name, type and where you sell' },
  { title: 'What you sell', icon: Package, fields: 'Products and audience' },
  { title: 'Numbers & goals', icon: Target, fields: 'Revenue and your main challenge' },
]

export function OnboardingView() {
  const { user, setBusiness, setView } = useSellr()
  const [step, setStep] = useState(0)

  const [name, setName] = useState('')
  const [businessType, setBusinessType] = useState('')
  const [platform, setPlatform] = useState('')
  const [website, setWebsite] = useState('')
  const [description, setDescription] = useState('')
  const [products, setProducts] = useState('')
  const [targetAudience, setTargetAudience] = useState('')
  const [currentMonthlyRevenue, setCurrentMonthlyRevenue] = useState('')
  const [monthlyRevenueGoal, setMonthlyRevenueGoal] = useState('')
  const [mainChallenge, setMainChallenge] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const canContinue = useMemo(() => {
    if (step === 0) return name.trim().length >= 2 && businessType.length > 0
    return true
  }, [step, name, businessType])

  function parseNumber(v: string): number | null {
    const trimmed = v.trim().replace(/[$,\s]/g, '')
    if (!trimmed) return null
    const n = Number(trimmed)
    return Number.isFinite(n) && n >= 0 ? n : null
  }

  async function handleSubmit() {
    setError(null)
    if (name.trim().length < 2) {
      setStep(0)
      setError('Business name is required.')
      return
    }
    if (!businessType) {
      setStep(0)
      setError('Business type is required.')
      return
    }
    setLoading(true)
    try {
      const data = await apiFetch<{ business: Business }>('/api/business', {
        method: 'POST',
        body: JSON.stringify({
          name: name.trim(),
          businessType,
          platform: platform.trim() || null,
          website: website.trim() || null,
          description: description.trim() || null,
          products: products.trim() || null,
          targetAudience: targetAudience.trim() || null,
          currentMonthlyRevenue: parseNumber(currentMonthlyRevenue),
          monthlyRevenueGoal: parseNumber(monthlyRevenueGoal),
          mainChallenge: mainChallenge.trim() || null,
          onboarded: true,
        }),
      })
      setBusiness(data.business)
      setView('dashboard')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save your business.')
    } finally {
      setLoading(false)
    }
  }

  const CurrentIcon = STEPS[step].icon

  return (
    <div className="flex min-h-screen flex-col sellr-backdrop">
      <header className="border-b border-border/60">
        <div className="mx-auto flex h-14 w-full max-w-2xl items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary text-primary-foreground text-xs font-bold">
              S
            </div>
            <span className="text-sm font-semibold tracking-tight">SELLR.AI</span>
          </div>
          <p className="text-xs text-muted-foreground">
            {user?.email ? `Signed in as ${user.email}` : null}
          </p>
        </div>
      </header>

      <main className="flex flex-1 items-start justify-center px-4 py-10">
        <div className="w-full max-w-2xl">
          {/* Progress */}
          <div className="mb-8">
            <div className="flex items-center justify-between gap-2">
              {STEPS.map((s, i) => (
                <div key={s.title} className="flex flex-1 items-center gap-2">
                  <motion.div
                    className={cn(
                      'flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-xs font-semibold',
                      i < step
                        ? 'border-primary bg-primary text-primary-foreground'
                        : i === step
                          ? 'border-primary text-primary'
                          : 'border-border text-muted-foreground'
                    )}
                    aria-current={i === step ? 'step' : undefined}
                    animate={{ scale: i === step ? 1.12 : 1 }}
                    transition={springSnappy}
                  >
                    {i < step ? '✓' : i + 1}
                  </motion.div>
                  <div className="hidden min-w-0 sm:block">
                    <p className={cn('truncate text-xs font-medium', i === step ? 'text-foreground' : 'text-muted-foreground')}>
                      {s.title}
                    </p>
                  </div>
                  {i < STEPS.length - 1 ? (
                    <div className={cn('h-px flex-1', i < step ? 'bg-primary/60' : 'bg-border')} />
                  ) : null}
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card p-5 md:p-6">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-primary/30 bg-primary/10">
                <CurrentIcon className="h-4.5 w-4.5 text-primary" aria-hidden />
              </div>
              <div>
                <h1 className="text-base font-semibold tracking-tight">{STEPS[step].title}</h1>
                <p className="text-xs text-muted-foreground">{STEPS[step].fields}</p>
              </div>
            </div>

            {/* Step content slides in the direction of travel */}
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={step}
                className="mt-6 space-y-4"
                initial={{ opacity: 0, x: 26, filter: 'blur(4px)' }}
                animate={{ opacity: 1, x: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, x: -18, filter: 'blur(4px)' }}
                transition={{ duration: 0.26, ease: EASE_OUT }}
              >
              {step === 0 ? (
                <>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="bizName">Business name *</Label>
                      <Input
                        id="bizName"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Northwind Templates"
                        autoFocus
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Business type *</Label>
                      <Select value={businessType} onValueChange={setBusinessType}>
                        <SelectTrigger aria-label="Business type">
                          <SelectValue placeholder="Select a type" />
                        </SelectTrigger>
                        <SelectContent>
                          {BUSINESS_TYPES.map((t) => (
                            <SelectItem key={t} value={t}>
                              {t}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="platform">Main platform</Label>
                      <Input
                        id="platform"
                        value={platform}
                        onChange={(e) => setPlatform(e.target.value)}
                        placeholder="e.g. Whop, Gumroad, Shopify"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="website">Website</Label>
                      <Input
                        id="website"
                        value={website}
                        onChange={(e) => setWebsite(e.target.value)}
                        placeholder="https://…"
                      />
                    </div>
                  </div>
                </>
              ) : null}

              {step === 1 ? (
                <>
                  <div className="space-y-1.5">
                    <Label htmlFor="description">Describe your business</Label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="What do you sell, and how? 1–2 sentences is enough."
                      rows={3}
                      maxLength={600}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="products">Products / offers</Label>
                    <Textarea
                      id="products"
                      value={products}
                      onChange={(e) => setProducts(e.target.value)}
                      placeholder="e.g. Notion template pack ($29), Pro membership ($15/mo)"
                      rows={2}
                      maxLength={500}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="audience">Target audience</Label>
                    <Input
                      id="audience"
                      value={targetAudience}
                      onChange={(e) => setTargetAudience(e.target.value)}
                      placeholder="e.g. Freelance designers who sell digital products"
                      maxLength={300}
                    />
                  </div>
                </>
              ) : null}

              {step === 2 ? (
                <>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="currentRev">Current monthly revenue (USD)</Label>
                      <Input
                        id="currentRev"
                        inputMode="decimal"
                        value={currentMonthlyRevenue}
                        onChange={(e) => setCurrentMonthlyRevenue(e.target.value)}
                        placeholder="e.g. 3200"
                      />
                      <p className="text-[11px] text-muted-foreground">
                        Optional — saved as [USER-REPORTED], never presented as measured data.
                      </p>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="goalRev">Monthly revenue objective (USD)</Label>
                      <Input
                        id="goalRev"
                        inputMode="decimal"
                        value={monthlyRevenueGoal}
                        onChange={(e) => setMonthlyRevenueGoal(e.target.value)}
                        placeholder="e.g. 10000"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="challenge">Main business challenge right now</Label>
                    <Textarea
                      id="challenge"
                      value={mainChallenge}
                      onChange={(e) => setMainChallenge(e.target.value)}
                      placeholder="e.g. Getting consistent traffic; my churn is too high; I don't know what to work on first."
                      rows={3}
                      maxLength={300}
                    />
                  </div>
                  <p className="rounded-lg border border-border bg-secondary/50 px-3 py-2.5 text-xs leading-relaxed text-muted-foreground">
                    After setup, add real metrics in <span className="text-foreground">Analytics</span> so your
                    team can analyze measured data. SELLR never invents numbers.
                  </p>
                </>
              ) : null}

              {error ? (
                <p role="alert" className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                  {error}
                </p>
              ) : null}
              </motion.div>
            </AnimatePresence>

            <div className="mt-6 flex items-center justify-between">
              <Button
                variant="ghost"
                size="sm"
                className="-ml-2 text-muted-foreground"
                onClick={() => (step === 0 ? setView('landing') : setStep(step - 1))}
                disabled={loading}
              >
                <ArrowLeft className="h-4 w-4" aria-hidden />
                {step === 0 ? 'Cancel' : 'Back'}
              </Button>
              {step < 2 ? (
                <Button onClick={() => setStep(step + 1)} disabled={!canContinue}>
                  Continue
                  <ArrowRight className="h-4 w-4" aria-hidden />
                </Button>
              ) : (
                <Button onClick={handleSubmit} disabled={loading}>
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
                  Finish setup
                </Button>
              )}
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-border/60 px-4 py-4 text-center text-xs text-muted-foreground">
        SELLR.AI — Your Personal AI Business Team
      </footer>
    </div>
  )
}
