'use client'

import { useEffect, useState } from 'react'
import { AGENT_META, type AgentType } from '@/lib/types'

/**
 * SELLR thinking indicator — Claude/Grok-style, bound to the REAL request
 * lifecycle.
 *
 * What makes it a real function, not decoration:
 *  1. Mount == request start. The parent renders this component only while
 *     the actual chat fetch is in flight (`sending === true`) and unmounts it
 *     in the same `finally` block that settles the request — success, error,
 *     or timeout all make it disappear. There is no independent timer that
 *     could keep it alive or animate it outside a real request.
 *  2. The label names the agent that is genuinely being consulted: the same
 *     `agent` state that is sent in the request body drives this component.
 *  3. The elapsed seconds counter shows REAL elapsed time measured from the
 *     moment the request started (component mount), like Claude's
 *     "Thinking for 12s". It is information, never fake progress — no
 *     percentages, no invented pipeline stages.
 *
 * Visual language (Claude/Grok): a compact inline row — breathing SELLR "S"
 * monogram chip, a shimmer-swept status line, three staggered pulse dots.
 * No giant orb, no fake multi-step theater.
 *
 * Engineering:
 *  - CSS animations are transform/opacity/background-position only and run on
 *    tiny elements — cheap, 60fps-friendly.
 *  - `prefers-reduced-motion` freezes every loop (globals.css kill list);
 *    the text remains fully readable.
 *  - Decorative layers are aria-hidden; the live region announces the state.
 */

interface SellrThinkingProps {
  /** The agent the in-flight request is actually sent to. */
  agent?: AgentType
}

export function SellrThinking({ agent }: SellrThinkingProps) {
  const [elapsedSec, setElapsedSec] = useState(0)

  // Real elapsed time since the request started (mount). One honest interval,
  // cleaned up when the request settles and the component unmounts.
  useEffect(() => {
    const started = Date.now()
    const timer = setInterval(() => {
      setElapsedSec(Math.floor((Date.now() - started) / 1000))
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const meta = agent ? AGENT_META[agent] : null
  const label = meta ? `${meta.name} is thinking` : 'SELLR is thinking'

  return (
    <div
      role="status"
      aria-live="polite"
      aria-label={`${label}…`}
      className="flex items-center gap-3 px-3.5 py-3 md:px-4"
    >
      {/* Breathing SELLR monogram chip */}
      <span
        aria-hidden
        className="sellr-think-breathe flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-primary/50 bg-primary shadow-[0_2px_14px_rgba(255,78,0,0.35)]"
      >
        <span className="text-sm font-black leading-none text-primary-foreground">S</span>
      </span>

      {/* Status line + pulse dots */}
      <span className="flex min-w-0 flex-wrap items-center gap-x-2.5 gap-y-1">
        <span className="sellr-think-text text-[13px] font-medium">{label}</span>
        <span aria-hidden className="flex items-end gap-1">
          <span className="sellr-think-dot h-1.5 w-1.5 rounded-full bg-primary/70" />
          <span className="sellr-think-dot sellr-think-dot-2 h-1.5 w-1.5 rounded-full bg-primary/70" />
          <span className="sellr-think-dot sellr-think-dot-3 h-1.5 w-1.5 rounded-full bg-primary/70" />
        </span>
        {/* Real elapsed time — shown once it is worth reading, never resets */}
        {elapsedSec >= 4 ? (
          <span className="text-[11px] tabular-nums text-muted-foreground">
            {elapsedSec}s
          </span>
        ) : null}
      </span>
    </div>
  )
}
