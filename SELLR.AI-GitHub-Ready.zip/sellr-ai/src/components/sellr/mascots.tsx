'use client'

import { motion, useReducedMotion } from 'framer-motion'
import { cn } from '@/lib/utils'
import type { AgentType } from '@/lib/types'

/**
 * Whop-style blob mascots — one playful character per agent.
 * Pure SVG so they stay crisp at any size and cost nothing to load.
 */

const BROWN = '#3a2a1c'
const BLACK = '#101010'

function CEOFace() {
  // Confident grin — white features on purple squircle
  return (
    <g fill="#ffffff">
      <ellipse cx="45" cy="50" rx="7" ry="11" />
      <ellipse cx="75" cy="50" rx="7" ry="11" />
      <path d="M38 68 Q60 94 82 68 Z" />
    </g>
  )
}

function AnalystFace() {
  // Skeptical smirk — dark features on tan circle
  return (
    <g fill={BROWN}>
      <rect x="34" y="46" width="17" height="7" rx="3.5" transform="rotate(-8 42 49)" />
      <circle cx="78" cy="50" r="6" />
      <rect x="54" y="74" width="20" height="6" rx="3" transform="rotate(-6 64 77)" />
    </g>
  )
}

function GrowthFace() {
  // Surprised go-getter — black features on yellow pentagon
  return (
    <g fill={BLACK}>
      <ellipse cx="46" cy="50" rx="6" ry="12" />
      <ellipse cx="74" cy="50" rx="6" ry="12" />
      <ellipse cx="60" cy="82" rx="8" ry="6" />
    </g>
  )
}

function RetentionFace() {
  // Calm and steady — white features on orange flower
  return (
    <g fill="#ffffff">
      <circle cx="46" cy="54" r="6.5" />
      <circle cx="74" cy="54" r="6.5" />
      <rect x="51" y="74" width="18" height="6" rx="3" />
    </g>
  )
}

function OperationsFace() {
  // Wide-eyed and busy — tall white eyes on orange burst
  return (
    <g fill="#ffffff">
      <rect x="42" y="38" width="14" height="32" rx="7" />
      <rect x="64" y="38" width="14" height="32" rx="7" />
    </g>
  )
}

const FACES: Record<AgentType, () => React.ReactNode> = {
  CEO: CEOFace,
  ANALYST: AnalystFace,
  GROWTH: GrowthFace,
  RETENTION: RetentionFace,
  OPERATIONS: OperationsFace,
}

const BODY_COLORS: Record<AgentType, string> = {
  CEO: '#6C4BF4',
  ANALYST: '#B08968',
  GROWTH: '#FFD43B',
  RETENTION: '#FF6A33',
  OPERATIONS: '#FF4E00',
}

function Body({ agent }: { agent: AgentType }) {
  const fill = BODY_COLORS[agent]
  switch (agent) {
    case 'CEO':
      // Rounded squircle
      return <rect x="14" y="14" width="92" height="92" rx="34" fill={fill} />
    case 'ANALYST':
      // Perfect circle
      return <circle cx="60" cy="60" r="46" fill={fill} />
    case 'GROWTH':
      // Pentagon with rounded joins
      return (
        <polygon
          points="60,12 103.7,43.8 87,95.2 33,95.2 16.3,43.8"
          fill={fill}
          stroke={fill}
          strokeWidth="14"
          strokeLinejoin="round"
        />
      )
    case 'RETENTION':
      // Scalloped flower (10-point soft gear)
      return (
        <polygon
          points="105,60 89.1,81.2 73.9,102.8 48.9,94.2 23.6,86.4 24,60 23.6,33.6 48.9,25.8 73.9,17.2 89.1,38.8"
          fill={fill}
          stroke={fill}
          strokeWidth="16"
          strokeLinejoin="round"
        />
      )
    case 'OPERATIONS':
      // Wavy burst (12-point seal)
      return (
        <polygon
          points="106,60 91.2,78 99.8,83 78,91.2 83,99.8 60,96 37,99.8 42,91.2 20.2,83 28.8,78 14,60 28.8,42 20.2,37 42,28.8 37,20.2 60,24 83,20.2 78,28.8 99.8,37 91.2,42"
          fill={fill}
          stroke={fill}
          strokeWidth="10"
          strokeLinejoin="round"
        />
      )
  }
}

export function AgentMascot({
  agent,
  className,
}: {
  agent: AgentType
  className?: string
}) {
  const Face = FACES[agent]
  return (
    <svg
      viewBox="0 0 120 120"
      role="img"
      aria-label={`${agent} agent mascot`}
      className={cn('h-16 w-16', className)}
    >
      <Body agent={agent} />
      <Face />
    </svg>
  )
}

const MASCOT_ORDER: AgentType[] = ['CEO', 'ANALYST', 'GROWTH', 'RETENTION', 'OPERATIONS']

/** Playful resting tilt offsets (degrees), echoing the reference layout. */
const TILTS = [-6, 3, -2, 6, -3]

export function MascotRow({
  className,
  size = 'h-14 w-14 md:h-20 md:w-20',
  gap = 'gap-4 md:gap-7',
}: {
  className?: string
  size?: string
  gap?: string
}) {
  const reduced = useReducedMotion()
  return (
    <motion.div
      className={cn('flex items-center justify-center', gap, className)}
      initial="hidden"
      animate="show"
      variants={{
        hidden: {},
        show: {
          transition: { staggerChildren: reduced ? 0 : 0.09, delayChildren: 0.15 },
        },
      }}
    >
      {MASCOT_ORDER.map((agent, i) => {
        const tilt = TILTS[i % TILTS.length]
        return (
          <motion.div
            key={agent}
            className="will-change-transform"
            variants={{
              hidden: { opacity: 0, scale: 0, rotate: tilt - 14, y: 20 },
              show: {
                opacity: 1,
                scale: 1,
                rotate: tilt,
                y: 0,
                transition: { type: 'spring', stiffness: 300, damping: 20 },
              },
            }}
            whileHover={
              reduced
                ? undefined
                : { rotate: 0, scale: 1.16, y: -6, transition: { type: 'spring', stiffness: 420, damping: 18 } }
            }
          >
            {/* Idle float lives on an inner wrapper so CSS transform loops never
                fight with framer-motion's inline transform management. */}
            <div className="animate-float" style={{ animationDelay: `${i * 0.65}s` }}>
              <AgentMascot agent={agent} className={size} />
            </div>
          </motion.div>
        )
      })}
    </motion.div>
  )
}
