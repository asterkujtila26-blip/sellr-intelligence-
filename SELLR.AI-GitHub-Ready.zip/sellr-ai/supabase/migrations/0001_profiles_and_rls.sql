-- ============================================================================
-- SELLR.AI — Supabase migration 0001
-- User profiles bound to auth.users + Row Level Security.
-- Run in the Supabase SQL editor (or `supabase db push`) once per project.
-- ============================================================================

-- 1. Profiles table -----------------------------------------------------------
-- One row per auth user, keyed by the SAME uuid as auth.users.id so every
-- business table can reference it as owner.
create table if not exists public.profiles (
  id            uuid primary key references auth.users (id) on delete cascade,
  email         text not null,
  full_name     text not null default '',
  avatar_url    text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

comment on table public.profiles is
  'Public profile data for SELLR.AI users. Mirrors auth.users 1:1 by id.';

-- Keep email in sync when auth.users changes (e.g. email update).
create or replace function public.handle_profile_email_sync()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  update public.profiles
     set email = new.email,
         updated_at = now()
   where id = new.id;
  return new;
end;
$$;

drop trigger if exists on_auth_email_updated on auth.users;
create trigger on_auth_email_updated
  after update on auth.users
  for each row
  when (old.email is distinct from new.email)
  execute function public.handle_profile_email_sync();

-- 2. Auto-create a profile for every new auth user ----------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(
      nullif(new.raw_user_meta_data ->> 'full_name', ''),
      nullif(new.raw_user_meta_data ->> 'name', ''),
      split_part(new.email, '@', 1)
    ),
    new.raw_user_meta_data ->> 'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Backfill profiles for users created before this migration existed.
insert into public.profiles (id, email, full_name, avatar_url)
select u.id,
       u.email,
       coalesce(
         nullif(u.raw_user_meta_data ->> 'full_name', ''),
         nullif(u.raw_user_meta_data ->> 'name', ''),
         split_part(u.email, '@', 1)
       ),
       u.raw_user_meta_data ->> 'avatar_url'
  from auth.users u
  on conflict (id) do nothing;

-- 3. Row Level Security -------------------------------------------------------
alter table public.profiles enable row level security;

-- A user can read only their own profile.
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own"
  on public.profiles for select
  using (auth.uid() = id);

-- A user can update only their own profile (and cannot steal another id).
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
  on public.profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- Profile creation happens via the trigger (security definer) and sign-up
-- metadata — inserts are not exposed to clients.
-- No delete policy: profiles are removed by the auth.users cascade.
